#!/usr/bin/env python3
"""Rebuild index data blocks and the self-contained Parkway review file.
Run from any directory: python build_standalone.py
Edit assets/styles.css, assets/tokens.css, assets/app.js or index.html. Keep the
roadway data read-only unless deliberately conducting a new source-data revision.
"""
from pathlib import Path
import argparse,json,re,sys

def replace_script(html, identifier, data):
    pattern=r'(<script\b(?=[^>]*\bid=["\']'+re.escape(identifier)+r'["\'])[^>]*>)(.*?)(</script>)'
    html,n=re.subn(pattern,lambda m:m.group(1)+data+m.group(3),html,flags=re.S)
    if n!=1: raise ValueError(f'Expected one {identifier} script; got {n}.')
    return html

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    page=(root/'index.html').read_text(encoding='utf-8')
    for key,name in [('study-data','study-data.json'),('county-data','county-navigation.json')]:
        data=(root/'data'/name).read_text(encoding='utf-8');json.loads(data)
        page=replace_script(page,key,data)
    tokens=(root/'assets/tokens.css').read_text(encoding='utf-8')
    page=replace_script(page,'parkway-tokens',tokens)
    (root/'index.html').write_text(page,encoding='utf-8')
    for name in ['tokens.css','styles.css']:
        text=(root/'assets'/name).read_text(encoding='utf-8')
        pattern=r'<link\b(?=[^>]*href=["\']assets/'+re.escape(name)+r'["\'])[^>]*>'
        # tokens remain in the text/plain node for the design-token download button.
        page,n=re.subn(pattern,lambda _: '<style>'+text+'</style>',page)
        if n!=1: raise ValueError(f'Expected stylesheet {name}; got {n}.')
    script=(root/'assets/app.js').read_text(encoding='utf-8')
    if '</script' in script.lower(): raise ValueError('Escape a literal closing-script tag before embedding JavaScript.')
    page,n=re.subn(r'<script\b[^>]*src=["\']assets/app\.js["\'][^>]*>\s*</script>',lambda _:'<script>'+script+'</script>',page)
    if n!=1: raise ValueError('Expected one assets/app.js script.')
    output=args.output or root/'GSP_Parkway_County_Refined.html'
    output.write_text(page,encoding='utf-8')
    print(f'Built {output} ({output.stat().st_size:,} bytes)')
    return 0
if __name__=='__main__':
    try: raise SystemExit(main())
    except (OSError,ValueError) as exc:
        print(f'Build failed: {exc}',file=sys.stderr);raise SystemExit(1)
