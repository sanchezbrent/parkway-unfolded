
/* The source geometry is immutable. Display transforms are translation + uniform scale. */
'use strict';
const DATA = JSON.parse(document.getElementById('study-data').textContent);
const COUNTY = JSON.parse(document.getElementById('county-data').textContent);
const countySections = COUNTY.counties;
const countyById = new Map(countySections.map(c=>[c.id,c]));
const countyCorridors = Object.fromEntries(countySections.map(c=>[c.id,{bounds:c.bounds,mainlines:c.mainlines}]));
let overviewTimer=null,searchCloseTimer=null;
const records = DATA.records;
// fid is a unique selection key; source_fid overrides it for disjoint source excerpts.
const sourceFID = r => r.source_fid ?? r.fid;
const groupOrder = DATA.group_order;
const byFID = new Map(records.map(r => [r.fid,r]));
const $ = id => document.getElementById(id);
const NS = 'http://www.w3.org/2000/svg';
const esc = s => String(s ?? '').replace(/[&<>"']/g,c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = n => Number(n).toLocaleString('en-US',{maximumFractionDigits:0});
const clamp = (v,a=0,b=1) => Math.max(a,Math.min(b,v));
const mix = (a,b,t) => a+(b-a)*t;
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const state = {group:'172',section:'',workspace:'overview',view:'context',selected:null,hover:null,playing:!reduced.matches,speed:1,time:2.3,tour:false,tourElapsed:0,collection:'all',morph:1,morphAnimation:null,detailIndex:-1,detailIDs:[],trace:0,focus:false,filters:{group:'',direction:'',kind:''},compare:[null,null],compareScale:'fit',detailVertices:false,compareContext:true,lastBySection:{}};
const groupNames = {'172':'Grand Avenue','171':'Glen Road','168':'Washington Avenue','166':'Highland & Linwood avenues','165':'Ridgewood Avenue','163':'Route 17','161':'Route 4','160':'Paramus Road','159':'Interstate 80','157':'US 46','156':'US 46 / Route 20 connection','155B':'Hazel Street / Passaic','155A':'Route 19 / Paterson','154':'US 46'};
const groupNotes = {'172':'Two selected branches. One quiet beginning to the study.','171':'A long exit and a southbound entrance, each with its own rhythm.','168':'Follow the turn from the Parkway to Washington Avenue.','166':'Two avenues. Two selected branches. Two different shapes.','165':'Four exits, four entrances. Follow a loop or isolate a single turn.','163':'Long approaches connect the Parkway and Route 17.','161':'A short-looking connection can hold a surprisingly long curve.','160':'A paired study of the Paramus Road connections.','159':'Long approaches and shared collectors bring I-80 into the picture.','157':'Four selected branches connect the Parkway and US 46.','156':'The selected records reach US 46 and Lakeview Avenue.','155B':'The Hazel Street connection, signed toward Passaic.','155A':'Follow the long Route 19 connection toward Paterson.','154':'Four selected US 46 connections, at the end of the original section.'};

Object.assign(groupNames, DATA.group_names);
Object.assign(groupNotes, DATA.group_notes);
const sectionForGroup=g=>countySections.find(c=>c.name===COUNTY.by_group[g].primary);
const sectionGroups=id=>id?(countyById.get(id)?.groups||groupOrder):groupOrder;

let mainFlows = [], atlasNodes = [], mainScene = null, detailScene = null, atlasGeoLayer = null, atlasW = 1000, atlasH = 650, atlasGridH = 650, atlasList = [], lastTick = 0, toastTimer = null, sceneVisible = true, atlasVisible = false, renderTimer = null;

function node(tag,attrs={},text='') {
  const n = document.createElementNS(NS,tag);
  for (const [k,v] of Object.entries(attrs)) if (v !== undefined && v !== null) n.setAttribute(k,v);
  if (text) n.textContent = text;
  return n;
}
function append(parent,tag,attrs={},text='') {const n=node(tag,attrs,text);parent.append(n);return n;}
function color(r,light=false) {return r.kind==='Exit' ? (light && !document.body.classList.contains('night') ? '#b36030' : '#f2ae79') : (light && !document.body.classList.contains('night') ? '#247a61' : '#8fd8bc');}
function xyPath(points,project) {return points.map((p,i)=>{const q=project(p);return `${i?'L':'M'}${q[0].toFixed(6)} ${q[1].toFixed(6)}`;}).join(' ');}
function fit(bounds,w,h,pad=30) {
  const p=typeof pad==='number'?{left:pad,right:pad,top:pad,bottom:pad}:pad;
  const [minX,minY,maxX,maxY]=bounds, s=Math.min((w-p.left-p.right)/Math.max(maxX-minX,1),(h-p.top-p.bottom)/Math.max(maxY-minY,1));
  const cx=(minX+maxX)/2,cy=(minY+maxY)/2,ox=p.left+(w-p.left-p.right)/2,oy=p.top+(h-p.top-p.bottom)/2;
  const fn=p=>[ox+(p[0]-cx)*s,oy-(p[1]-cy)*s];
  fn.s=s; fn.cx=cx;fn.cy=cy;fn.ox=ox;fn.oy=oy; return fn;
}
const lengths = new Map(records.map(r=>{let t=0;const a=[0];for(let i=1;i<r.source_xy.length;i++){t+=Math.hypot(r.source_xy[i][0]-r.source_xy[i-1][0],r.source_xy[i][1]-r.source_xy[i-1][1]);a.push(t);}return [r.fid,{cumulative:a,total:t}];}));
function sample(r,t) {
  const {cumulative,total}=lengths.get(r.fid), d=clamp(t)*total;
  let lo=1,hi=cumulative.length-1;
  while(lo<hi){const m=(lo+hi)>>1;if(cumulative[m]<d)lo=m+1;else hi=m;}
  const i=lo,a=r.source_xy[i-1],b=r.source_xy[i], f=(d-cumulative[i-1])/Math.max(1e-12,cumulative[i]-cumulative[i-1]);
  return {xy:[mix(a[0],b[0],f),mix(a[1],b[1],f)],angle:Math.atan2(-(b[1]-a[1]),b[0]-a[0])*180/Math.PI,distance:d};
}
function addStaticChevron(parent,r,project,light=false) {
  const v=sample(r,.54),p=project(v.xy);
  append(parent,'path',{d:'M-4.5 -3.2L0 0L-4.5 3.2',transform:`translate(${p[0]},${p[1]}) rotate(${v.angle})`,fill:'none',stroke:light?'#fff7e7':'#eff6e2','stroke-width':1.3,'stroke-linecap':'round','stroke-linejoin':'round','pointer-events':'none'});
}
function addDefs(svg,id) {
  const defs=append(svg,'defs');
  const f=append(defs,'filter',{id:`glow-${id}`,x:'-150%',y:'-150%',width:'400%',height:'400%'});
  append(f,'feGaussianBlur',{stdDeviation:2.6,result:'blur'});
  const m=append(f,'feMerge');append(m,'feMergeNode',{in:'blur'});append(m,'feMergeNode',{in:'SourceGraphic'});
}
function renderScene(svg,list,context,bounds,{width=1000,height=650,mode='context',interactive=false,grid=true,detail=false,id='main'}={}) {
  svg.replaceChildren();svg.setAttribute('viewBox',`0 0 ${width} ${height}`);
  append(svg,'title',{},detail?`${list[0].number}: ${list[0].direction} ${list[0].kind.toLowerCase()} — ${list[0].road}`:`Garden State Parkway interchange ${state.group}: ${groupNames[state.group]}`);
  append(svg,'desc',{},'Original NJDOT NAD83 / New Jersey centerline coordinates. Grid north up. Width and motion are illustrative. Crossings do not establish turn permissions.');
  addDefs(svg,id);
  const project=fit(bounds,width,height,{left:45,right:45,top:32,bottom:58});
  if(grid){
    const gridG=append(svg,'g',{'aria-hidden':'true'}),step=[100,250,500,1000,2500,5000,10000].find(n=>n*project.s>=68)||10000;
    const minX=project.cx-(width/2)/project.s,maxX=project.cx+(width/2)/project.s,minY=project.cy-(height/2)/project.s,maxY=project.cy+(height/2)/project.s;
    for(let x=Math.ceil(minX/step)*step;x<maxX;x+=step){const q=project([x,project.cy]);append(gridG,'line',{x1:q[0],x2:q[0],y1:0,y2:height,class:'map-grid'});}
    for(let y=Math.ceil(minY/step)*step;y<maxY;y+=step){const q=project([project.cx,y]);append(gridG,'line',{x1:0,x2:width,y1:q[1],y2:q[1],class:'map-grid'});}
    append(gridG,'text',{x:29,y:height-10,class:'grid-label',opacity:.45},`NJ state plane · ${fmt(project.cx)} E / ${fmt(project.cy)} N`);
  }
  const selectedFIDs=new Set(list.map(sourceFID));
  // A single global casing pass, followed by a surface pass, avoids dark rings at joins.
  const ctx=context.filter(l=>!selectedFIDs.has(l.fid)||l.source_remainder);
  const casing=append(svg,'g',{'aria-hidden':'true'}),surfaces=append(svg,'g',{'aria-hidden':'true'});
  for(const l of ctx){const st=contextStyle(l.role,mode);if(!st.opacity)continue;const d=xyPath(l.xy,project);if(l.role!=='local')append(casing,'path',{d,stroke:'#243331','stroke-width':st.w+4.5,class:'ramp-casing',opacity:st.opacity});append(surfaces,'path',{d,stroke:st.ink,'stroke-width':st.w,opacity:st.opacity,class:l.role==='mainline'?'main-road':l.role==='connector'?'connecting-road':'local-road','data-source-sri':l.sri,'data-source-fid':l.fid});}
  for(const r of list)append(casing,'path',{d:xyPath(r.source_xy,project),stroke:'#243331','stroke-width':10.5,class:'ramp-casing','data-ramp-casing':r.fid});
  const rampLayer=append(svg,'g'),flows=[];
  for(const r of list){
    const g=append(rampLayer,'g',{class:'source-ramp','data-fid':r.fid,role:interactive?'button':undefined,tabindex:interactive?'0':undefined,'aria-label':interactive?`Highlight exit ${r.number}, ${r.direction} ${r.kind.toLowerCase()}, ${r.road}`:undefined});
    const d=xyPath(r.source_xy,project);
    const surface=append(g,'path',{d,class:'ramp-surface',stroke:color(r),'stroke-width':detail?6:6.5,'data-source-sri':r.sri,'data-source-vertices':r.vertex_count,'data-source-fid':sourceFID(r),'data-selection-key':r.fid});
    addStaticChevron(g,r,project);
    if(mode==='vertices'){
      const vertices=append(g,'g',{'aria-hidden':'true'});
      r.source_xy.forEach((p,i)=>{const q=project(p);append(vertices,'circle',{cx:q[0],cy:q[1],r:detail?2.3:2,class:'vertex-dot',fill:'#243331',stroke:color(r),'stroke-width':1,opacity:.96});});
      const start=project(r.source_xy[0]),end=project(r.source_xy.at(-1));
      append(vertices,'circle',{cx:start[0],cy:start[1],r:4,fill:'#f5f5dd',stroke:'#243331','stroke-width':1.2});
      append(vertices,'circle',{cx:end[0],cy:end[1],r:4,fill:'#243331',stroke:'#f5f5dd','stroke-width':1.5});
    }
    const flowLayer=append(g,'g',{'aria-hidden':'true',class:'particle'});
    const parts=[];
    for(let j=0;j<5;j++)parts.push(append(flowLayer,'circle',{r:Math.max(.7,2.8-j*.42),fill:j===0?'#fffde8':color(r),opacity:1-j*.16,filter:j===0?`url(#glow-${id})`:undefined}));
    const flow={r,g,parts,project,surface,layer:flowLayer};flows.push(flow);
    if(interactive){
      append(g,'path',{d,class:'ramp-hit'});
      g.addEventListener('pointerenter',e=>{state.hover=r.fid;updateHighlight();showMapTooltip(r,e);});
      g.addEventListener('pointermove',e=>showMapTooltip(r,e));
      g.addEventListener('pointerleave',()=>{state.hover=null;$('mapTooltip').hidden=true;updateHighlight();});
      g.addEventListener('click',()=>selectBranch(r.fid));
      g.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();selectBranch(r.fid);}});
    }
  }
  return {svg,project,flows,width,height,list,bounds};
}
function setPlaying(v) {
  state.playing=v;$('motionToggle').setAttribute('aria-pressed',String(v));$('motionToggle').innerHTML=v?'<span aria-hidden="true">Ⅱ</span> Pause flow':'<span aria-hidden="true">▶</span> Play flow';
  if(!v&&state.tour)toggleTour(false);
}
function renderFlows(flows,time) {
  for(const f of flows){
    const cycle=6.4+Math.min(9,f.r.length_ft/600),t=(time/cycle+(f.r.panel*.137))%1;
    for(let j=0;j<f.parts.length;j++){const q=t-j*.008;if(q<0||q>1){f.parts[j].setAttribute('opacity',0);continue;}const p=f.project(sample(f.r,q).xy);f.parts[j].setAttribute('cx',p[0]);f.parts[j].setAttribute('cy',p[1]);f.parts[j].setAttribute('opacity',(1-j*.18)*Math.min(1,t*18,(1-t)*18));}
  }
}
function setMorph(target,{animate=true}={}) {
  if(!atlasNodes.length)return;
  const baseH=atlasBaseHeight();$('atlasSVG').style.height=`${target?atlasGridH:baseH}px`;
  if(!animate||reduced.matches){state.morph=target;state.morphAnimation=null;updateAtlasTransform(target);updateAtlasLabels();renderAtlasFlows(state.time);}
  else state.morphAnimation={from:state.morph,to:target,start:performance.now(),duration:1850};
}
function renderAtlasFlows(time) {
  for(const a of atlasNodes){const t=(time/(8+Math.min(7,a.r.length_ft/800))+a.r.panel*.073)%1,v=sample(a.r,t);a.tracer.setAttribute('cx',v.xy[0]-a.cx);a.tracer.setAttribute('cy',a.cy-v.xy[1]);a.tracer.setAttribute('r',2.1/a.s);a.tracer.setAttribute('opacity',Math.min(1,t*18,(1-t)*18)*.8);}
}
function updateTrace() {
  const r=byFID.get(state.detailIDs[state.detailIndex]);if(!r||!detailScene)return;
  const v=sample(r,state.trace),p=detailScene.project(v.xy);detailScene.tracer.setAttribute('transform',`translate(${p[0]},${p[1]})`);
  const compass=((v.angle+90)%360+360)%360,dirs=['N','NE','E','SE','S','SW','W','NW'];
  $('traceDistance').textContent=`${fmt(v.distance)} / ${fmt(r.length_ft)} ft · ${dirs[Math.round(compass/45)%8]}`;
  $('traceProgress').setAttribute('aria-valuetext',`${fmt(v.distance)} feet along the source centerline; local grid bearing ${dirs[Math.round(compass/45)%8]}`);
}
function toast(message) {clearTimeout(toastTimer);$('toast').textContent=message;$('toast').hidden=false;toastTimer=setTimeout(()=>$('toast').hidden=true,3500);}
function save(filename,text,type) {const url=URL.createObjectURL(new Blob([text],{type})),a=document.createElement('a');a.href=url;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast(`Saved ${filename}`);}
function saveSVG(svg,filename,selectedRecords) {
  const clone=svg.cloneNode(true),vb=svg.viewBox.baseVal;
  clone.setAttribute('xmlns',NS);clone.setAttribute('width',vb.width);clone.setAttribute('height',vb.height);clone.removeAttribute('style');
  const sourceEls=[svg,...svg.querySelectorAll('*')],clonedEls=[clone,...clone.querySelectorAll('*')],props=['fill','fill-opacity','stroke','stroke-width','stroke-opacity','stroke-linecap','stroke-linejoin','stroke-dasharray','font-family','font-size','font-weight','letter-spacing','text-anchor','opacity','vector-effect'];
  sourceEls.forEach((e,i)=>{const c=clonedEls[i];if(!c)return;const css=getComputedStyle(e);for(const p of props){const val=css.getPropertyValue(p);if(val)c.style.setProperty(p,val);}c.removeAttribute('tabindex');c.removeAttribute('role');c.style.removeProperty('cursor');});
  clone.querySelectorAll('.particle,.ramp-hit,.atlas-compare').forEach(n=>n.remove());
  const bg=node('rect',{width:vb.width,height:vb.height,fill:svg.id==='atlasSVG'?getComputedStyle(document.body).getPropertyValue('--paper').trim():getComputedStyle(document.body).getPropertyValue('--stage').trim()});clone.insertBefore(bg,clone.firstChild);
  const md=node('metadata',{},JSON.stringify({title:'Garden State Parkway source centerlines',source:DATA.provenance.official_source_url,snapshot:'2025-08-21',crs:DATA.crs,method:'Translation and uniform scaling only. Static display snapshot. Width does not represent lane count or pavement width. Source coordinate arrays below are unchanged.',records:selectedRecords.map(r=>({fid:sourceFID(r),selection_key:r.fid,source_fid:sourceFID(r),sri:r.sri,source_xy:r.source_xy,source_selection:r.source_selection||'complete_feature',source_vertex_range:r.source_vertex_range||null}))}));clone.insertBefore(md,clone.firstChild);
  save(filename,'<?xml version="1.0" encoding="UTF-8"?>\n'+new XMLSerializer().serializeToString(clone),'image/svg+xml');
}
function saveCSV() {
  const fields=['panel','number','group','kind','direction','road','selection_key','source_fid','sri','vertex_count','length_ft','checked_endpoint','expected_connection_sri','connection_gap_ft','source_selection','source_vertex_range','note'];
  const q=v=>'"'+String(v&&typeof v==='object'?JSON.stringify(v):(v??'')).replace(/"/g,'""')+'"';
  const csv=[fields.concat(['raw_sld_name','raw_direction']).map(q).join(','),...records.map(r=>fields.map(k=>q(k==='selection_key'?r.fid:k==='source_fid'?sourceFID(r):r[k])).concat(q(r.source_attributes.SLD_NAME),q(r.source_attributes.DIRECTION)).join(','))].join('\r\n');save(`GSP_${records.length}_branch_source_table.csv`,csv,'text/csv;charset=utf-8');
}
function populateSources() {
  const audit=DATA.audit;
  $('endpointText').textContent=`${audit.endpoint_count} endpoints were reviewed: ${audit.exact_endpoint_count} have exact coordinate adjacency to their expected or evidenced connecting feature; ${audit.nonzero_endpoint_count} retain nonzero source gaps (largest ${audit.max_endpoint_gap_ft.toFixed(4)} ft); ${audit.unmapped_venue_endpoint_count} are open venue endpoints without adjoining public-road geometry. Coordinates are not snapped, and a geometric crossing is not proof of a permitted turn.`;
  $('verificationDetails').innerHTML=`<p><strong>${audit.record_count} of ${audit.record_count} selections match the uploaded NJDOT archive at their stated source ranges.</strong> All ${fmt(audit.source_vertex_count)} XY vertices, FIDs and SRIs were compared using GeoPandas/GDAL and an independent standard-library binary SHP/SHX reader. The preceding 310 records, their individual contexts and 71 group contexts remain unchanged. The final batch adds 49 complete source features. ${audit.complete_feature_count} selections are complete source features; ${audit.contiguous_excerpt_count} are explicitly indexed US 9 route excerpts at 83, 80, 50 and 48.</p><p>Only context has interpolated boundary clipping. The four US 9 excerpts use consecutive original vertices with explicit source ranges and no synthetic cut points. Two disjoint excerpts share source FID 50633; their independent application keys prevent overwriting or merging. No selected path is smoothed or simplified. Local contextual streets are limited for legibility. Express roadways are included where present. The geographic-to-atlas transformation still uses translation and uniform scaling only.</p><p>Archive publication date: <code>2025-08-21</code>. Extension checked October 12, 2026 using the user-uploaded archive. SHA-256: <code>${esc(DATA.provenance.official_source_zip_sha256)}</code>.</p><p>Base HTML: <code>${esc(DATA.provenance.input_filename)}</code>. Source gaps, unrepresented venue endpoints and uncertain sign suffixes are retained as notes, not hidden by redrawing. Source lengths and shape ratios are calculated from projected XY coordinates. WGS84 export is a transformed derivative; projected JSON is the exact audit source.</p>`;
  $('sourceTable').innerHTML=records.map(r=>`<tr><td>${esc(r.number)}</td><td>${esc(r.direction)}<br>${esc(r.kind)}</td><td>${esc(r.road)}</td><td>${fmt(r.length_ft)} ft</td><td><code>${esc(r.sri)}</code><br>FID ${sourceFID(r)}${r.source_vertex_range?`<br>Vertices ${r.source_vertex_range.start}–${r.source_vertex_range.end_inclusive}`:''}</td><td><button data-inspect="${r.fid}">Open ↗</button></td></tr>`).join('');
  $('sourceTable').querySelectorAll('[data-inspect]').forEach(b=>b.addEventListener('click',()=>openDetail(Number(b.dataset.inspect))));
  $('saveGeoJSON').hidden=!DATA.geojson;
}

/* Display layer. The preceding 310 selections are retained; 49 final selections complete the study to Interchange 0. */
const FEATURED_FIDS = new Set([5527,5524,5951,5725,5499,5497,5938,5490,5488,3789,3962,5600,5918,5689,5481,...(DATA.new_featured_fids||[])]);
// Startup scope is defined once in state.
let atlasHeadingLayer=null, searchItems=[],searchActive=-1,detailReturnFocus=null,compareReturnFocus=null,atlasDirty=true,compareProjects=[];
const textCanvas=document.createElement('canvas'),textMeasure=textCanvas.getContext('2d');
const movement=r=>`${r.direction} ${r.kind.toLowerCase()}`;
const numberTitle=r=>`${r.kind==='Entrance'?'Interchange':'Exit'} ${r.number}`;
function wrappedLines(text,maxWidth,size=13,maxLines=8) {
  textMeasure.font=`${size}px Arial`;
  const words=String(text).split(/\s+/),lines=[];let line='';
  for(const word of words){const next=line?line+' '+word:word;if(line&&textMeasure.measureText(next).width>maxWidth){lines.push(line);line=word;}else line=next;}
  if(line)lines.push(line);
  return lines; // Never truncate a connecting-road label.
}
function svgMultiline(parent,text,x,y,maxWidth,{size=13,lineHeight=17,className='atlas-road',fill=null}={}) {
  const lines=wrappedLines(text,maxWidth,size),t=append(parent,'text',{x,y,class:className,fill,'font-size':size});
  lines.forEach((line,i)=>append(t,'tspan',{x,dy:i?lineHeight:0},line));return lines.length;
}
function sourceBounds(r){return DATA.metrics_by_fid[r.fid].source_xy_bounds;}
function padBounds(b,f=.08,min=45){const p=Math.max(min,(b[2]-b[0])*f,(b[3]-b[1])*f);return [b[0]-p,b[1]-p,b[2]+p,b[3]+p];}
function warningFor(r) {
  const ep=DATA.endpoint_attachments[r.fid],notes=[];
  if(r.source_vertex_range){const q=r.source_vertex_range;notes.push(`US 9 source excerpt: original vertices ${q.start}–${q.end_inclusive} (zero-based, inclusive). Includes a highway approach, not just a stand-alone ramp.`);}
  if(['start','end'].some(k=>!ep[k].nearest_eligible_context))notes.push('An adjoining venue road is not represented in this source. The endpoint remains open.');
  const gaps=['start','end'].map(k=>ep[k].nearest_eligible_context?.gap_ft||0).filter(n=>n>=.001);
  if(gaps.length)notes.push(`A source endpoint gap of ${Math.max(...gaps).toFixed(3)} ft is retained, not snapped. This is not a measurement of pavement separation.`);
  if(r.group==='142'&&r.direction==='Southbound')notes.push('The supplied study does not verify an A/B sign suffix for this southbound branch.');
  if(r.group==='143')notes.push('The supplied study retains group 143 without unverified A/B/C sign suffixes.');
  if(r.display_warning)notes.push(r.display_warning);
  return notes.join(' ');
}
function branchScope(r) {
  if(r.source_vertex_range)return 'Explicitly indexed US 9 approach excerpt. Its recorded start and end are disclosed in the source details.';
  const ep=DATA.endpoint_attachments[r.fid];
  const isRamp=n=>n&&(/^FR /i.test(n.name)||byFID.has(n.fid));
  if(['start','end'].some(k=>!ep[k].nearest_eligible_context))return 'Open venue endpoint; adjoining internal roads are not drawn.';
  if(['start','end'].some(k=>isRamp(ep[k].nearest_eligible_context)))return 'This source branch meets another ramp or collector; the full trip may continue beyond it.';
  return 'One selected source branch; connecting roads are not part of this isolated shape.';
}




function contextStyle(role,mode) {
  if(role==='mainline')return {w:4.8,ink:'#9ab3a0',opacity:mode==='clean'?.17:.65};
  if(role==='connector')return {w:2.8,ink:'#7c9b88',opacity:mode==='clean'?.08:.43};
  return {w:.85,ink:'#769480',opacity:mode==='clean'?0:.15};
}

// Source-route labels for the new groups. No new geographic features are added.
const CONTINUATION_ROAD_LABELS = {
 '63':['00000072__','NJ 72'], '58':['00000539__','CR 539'],
 '52':['03000654__','CR 654'], '50':['00000009__','US 9'],
 '48':['00000009__','US 9'], '44':['00000561A_','Pomona Road'],
 '41':['00000561__','Jimmie Leeds Road'], '40':['00000030__','US 30'],
 '38':['00000446__','Atlantic City Expressway'], '37':['01000608__','Washington Avenue'],
 '36':['00000563__','Tilton Road (CR 563)'],
 '30':['01211145__','Laurel Drive'],'29':['00000009__','US 9'],
 '25':['05000623__','Roosevelt Boulevard'],'20':['00000050__','NJ 50'],
 '17':['05000625__','Sea Isle Boulevard'],'13':['05000601__','Avalon Boulevard'],
 '12':['00000009__','US 9'],'11':['05000609__','Crest Haven Road'],
 '10':['05000657__','Stone Harbor Boulevard'],'9':['05000674__','Shell Bay Avenue'],
 '6':['00000147__','NJ 147'],'4':['00000047__','NJ 47'],'0':['00000109__','NJ 109']
};
function labelRoads(scene,context) {
  if(state.view==='clean'||state.focus)return;
  const g=append(scene.svg,'g',{'aria-hidden':'true',class:'road-labels'}),placed=[];
  const keys=[['00000444__','Parkway northbound'],['00000444_S','Parkway southbound']];
  const primary=context.find(l=>l.role!=='local'&&!keys.some(x=>x[0]===l.sri)&&/^(?:I[- ]?\d+|NJ \d+|US \d+)(?: SECONDARY)?$/.test(l.name));
  const connection=CONTINUATION_ROAD_LABELS[state.group];
  if(connection&&context.some(l=>l.sri===connection[0]))keys.push(connection);
  else if(primary)keys.push([primary.sri,primary.name.replace(/ SECONDARY$/,'')]);
  keys.forEach(([sri,label],idx)=>{
    const lines=context.filter(l=>l.sri===sri),pts=lines.flatMap(l=>l.xy.map(scene.project)).filter(p=>p[0]>24&&p[0]<scene.width-24&&p[1]>35&&p[1]<scene.height-65);
    if(!pts.length)return;const p=pts[Math.min(pts.length-1,Math.floor(pts.length*(idx%2?.22:.78)))];
    const font=scene.width<500?10:12;textMeasure.font=`${font}px Arial`;const tw=textMeasure.measureText(label).width;
    let x=clamp(p[0]+(idx%2?-tw-24:24),14,scene.width-tw-15),y=clamp(p[1]+(idx%2?25:-18),35,scene.height-80);
    for(let j=0;j<5&&placed.some(q=>Math.abs(y-q.y)<23&&x<q.x+q.w+8&&x+tw>q.x-8);j++)y+=25;
    if(y>scene.height-65)return;placed.push({x,y,w:tw});
    append(g,'path',{d:`M${p[0]} ${p[1]}L${x+(idx%2?tw:0)} ${y-4}`,class:'road-label-line'});
    append(g,'text',{x,y,class:'road-label'},label);
  });
}
function setSelectionDisplay() {
  const r=byFID.get(state.selected);$('selectionPrompt').hidden=!!r;$('selectionCopy').hidden=!r;$('selectionActions').hidden=!r;$('clearBranch').hidden=!r;
  if(r){$('selectionTitle').textContent=`${r.number} · ${movement(r)}`;$('selectionMeta').textContent=r.road;$('mapWarning').textContent=warningFor(r);$('focusBranch').textContent=state.focus?'Whole interchange':'Focus ramp';$('focusBranch').setAttribute('aria-pressed',String(state.focus));$('compareSelected').textContent=state.compare.includes(r.fid)?'✓ Added':'+ Compare';$('compareSelected').setAttribute('aria-pressed',String(state.compare.includes(r.fid)));}
  else $('mapWarning').textContent='';
}
function drawMain() {
  if($('explore').hidden)return;
  const group=DATA.groups[state.group],all=group.fids.map(id=>byFID.get(id)),focus=state.focus&&byFID.get(state.selected),list=focus?[focus]:all;
  const width=Math.max(260,$('stageMap').clientWidth),height=Math.max(260,$('stageMap').clientHeight);
  let bounds=padBounds(group.bounds,.08,90),context=group.wide_context_lines||group.context_lines;
  if(focus){bounds=padBounds(sourceBounds(focus),.12,85);context=context.concat(all.filter(r=>r.fid!==focus.fid&&!context.some(l=>l.fid===r.fid)).map(r=>({fid:r.fid,sri:r.sri,name:r.source_attributes.SLD_NAME,role:'connector',xy:r.source_xy})));}
  mainScene=renderScene($('mainSVG'),list,context,bounds,{width,height,mode:state.view,interactive:true,id:'main'});mainFlows=mainScene.flows;
  $('mainSVG').setAttribute('aria-label',`Interchange ${state.group}, ${groupNames[state.group]}. ${focus?'Focused selected branch.':'Select a ramp, or use the branch list below.'}`);
  labelRoads(mainScene,context);
  document.querySelectorAll('[data-view]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.view===state.view)));
  const scaleVal=[25,50,100,200,500,1000,2000,5000,10000].find(n=>n*mainScene.project.s>=55)||10000;
  $('scaleLine').style.width=`${scaleVal*mainScene.project.s}px`;$('scaleLabel').textContent=`${fmt(scaleVal)} US survey ft`;
  setSelectionDisplay();updateHighlight();renderFlows(mainFlows,state.time);
}
function updateHighlight() {
  const active=state.hover||state.selected;
  for(const f of mainFlows){f.g.style.opacity=!active||f.r.fid===active?1:.18;f.surface.setAttribute('stroke-width',f.r.fid===active?7.4:5.5);f.layer.style.visibility=active&&f.r.fid!==active?'hidden':'visible';f.g.setAttribute('aria-pressed',String(f.r.fid===state.selected));}
  document.querySelectorAll('.branch-row').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.fid)===state.selected)));
}
function selectBranch(fid) {
  if(state.tour)toggleTour(false);
  const wasFocus=state.focus;state.selected=state.selected===fid?null:fid;state.hover=null;$('mapTooltip').hidden=true;
  if(!state.selected)state.focus=false;
  setSelectionDisplay();if(state.focus||wasFocus)drawMain();else updateHighlight();atlasDirty=true;
}
function showMapTooltip(r,e) {
  if(e.pointerType==='touch')return;
  const box=$('stageMap').getBoundingClientRect(),tip=$('mapTooltip');
  tip.innerHTML=`<strong>${esc(r.number)} · ${esc(movement(r))}</strong>${esc(r.road)}<br>${fmt(r.length_ft)} ft along the recorded line`;
  tip.hidden=false;tip.style.left=clamp(e.clientX-box.left+15,10,Math.max(10,box.width-250))+'px';tip.style.top=clamp(e.clientY-box.top-30,10,Math.max(10,box.height-100))+'px';
}
function setGroup(g,{fromTour=false,scrollNav=false,drawAtlas:refreshAtlas=true,preserveSelection=false}={}) {
  if(!DATA.groups[g])return;if(state.tour&&!fromTour)toggleTour(false);
  const different=state.group!==g;state.group=g;const sec=sectionForGroup(g);state.lastBySection[sec.id]=g;
  if(state.section&&!sectionGroups(state.section).includes(g)){state.section='';state.filters.group='';}
  if(different&&(!preserveSelection||!DATA.groups[g].fids.includes(state.selected))){state.selected=null;state.focus=false;state.hover=null;}
  // Inspecting a branch does not rewrite the collection filters.
  $('groupNumber').textContent=g;if($('accessLabel'))$('accessLabel').textContent=g==='12'?'Access':'Exit';$('groupRoad').textContent=groupNames[g];
  const list=DATA.groups[g].fids.map(id=>byFID.get(id)),ex=list.filter(r=>r.kind==='Exit').length,en=list.length-ex;
  $('groupSummary').textContent=[ex?`${ex} selected ${ex===1?'exit':'exits'}`:'',en?`${en} ${en===1?'entrance':'entrances'}`:''].filter(Boolean).join(' · ');
  $('groupBranchCount').textContent=`Choose a ramp · ${list.length}`;$('groupPosition').textContent=String(groupOrder.indexOf(g)+1).padStart(2,'0');$('groupTotal').textContent=scopedGroups().length;$('groupPosition').textContent=String(scopedGroups().indexOf(g)+1).padStart(2,'0');
  $('sidebarStatus').textContent='Original NJDOT centerlines';$('mapTooltip').hidden=true;
  $('branchList').innerHTML=list.map(r=>`<button class="branch-row" data-fid="${r.fid}" aria-pressed="${state.selected===r.fid}" style="--branch-color:${color(r,true)}"><span class="branch-dot" aria-hidden="true"></span><span><strong><b>${esc(r.number)}</b><span>${esc(movement(r))}</span></strong><small>${esc(r.road)}</small></span><span class="row-arrow" aria-hidden="true">↗</span></button>`).join('');
  $('branchList').querySelectorAll('button').forEach(b=>{b.addEventListener('click',()=>selectBranch(Number(b.dataset.fid)));b.addEventListener('pointerenter',()=>{state.hover=Number(b.dataset.fid);updateHighlight();});b.addEventListener('pointerleave',()=>{state.hover=null;updateHighlight();});b.addEventListener('focus',()=>{state.hover=Number(b.dataset.fid);updateHighlight();});b.addEventListener('blur',()=>{state.hover=null;updateHighlight();});});
  renderExitNav();refreshSharedControls();drawLocator();setSelectionDisplay();drawMain();atlasDirty=true;
  if(refreshAtlas&&state.workspace==='atlas')drawAtlas();
  if(scrollNav){const btn=$('exitNav').querySelector(`[data-group="${g}"]`);if(btn) $('exitNav').scrollTo({left:btn.offsetLeft-$('exitNav').offsetLeft-$('exitNav').clientWidth/2+btn.clientWidth/2,behavior:reduced.matches?'instant':'smooth'});}
  $('branchList').scrollTop=0;$('branchList').scrollLeft=0;
}

function normalSearch(s){return String(s).toLowerCase().replace(/\b(?:exit|interchange|access)\s*(?=\d)/g,'').replace(/\binterstate\s*(\d+)/g,'i$1').replace(/\b(?:route|rt\.?|nj)\s*(\d+)/g,'route$1').replace(/\bus\s*(\d+)/g,'us$1').replace(/\bi[- ]*(\d+)/g,'i$1').replace(/[^a-z0-9]+/g,' ').trim();}

function closeSearch() {$('searchPanel').hidden=true;$('exitSearch').setAttribute('aria-expanded','false');$('exitSearch').removeAttribute('aria-activedescendant');searchActive=-1;}

function atlasBaseHeight(){return window.innerWidth<681?650:620;}
function atlasFiltered() {
  return records.filter(r=>sectionGroups(state.section).includes(r.group)&&(state.collection==='all'||state.collection==='signature'&&r.overview_order!==null||state.collection==='featured'&&FEATURED_FIDS.has(r.fid))&&(!state.filters.group||r.group===state.filters.group)&&(!state.filters.direction||r.direction===state.filters.direction)&&(!state.filters.kind||r.kind===state.filters.kind)).sort((a,b)=>a.panel-b.panel);
}
function drawAtlas() {
  if($('atlas').hidden){atlasDirty=true;return;}
  atlasDirty=false;state.morphAnimation=null;state.morph=state.morph>.5?1:0;
  const svg=$('atlasSVG');svg.replaceChildren();atlasNodes=[];atlasList=atlasFiltered();
  const small=window.innerWidth<681;atlasW=Math.max(260,$('atlasCanvas').clientWidth);const baseH=atlasBaseHeight(),cols=small?2:Math.max(2,Math.min(state.collection==='featured'?4:5,Math.floor(atlasW/225))),pad=small?0:5,gap=small?12:22,tileW=(atlasW-2*pad-(cols-1)*gap)/cols;
  const slotLayouts=[],sectionHeaders=[];let offset=10;
  for(const section of countySections){const list=atlasList.filter(r=>state.section?section.id===state.section:COUNTY.by_group[r.group].primary===section.name);if(!list.length)continue;
    sectionHeaders.push({section,y:offset+17,count:list.length});offset+=48;
    for(let start=0;start<list.length;start+=cols){const row=list.slice(start,start+cols),maxRoadLines=Math.max(...row.map(r=>wrappedLines(r.road,tileW-24,small?12:13).length)),tileH=(small?250:263)+maxRoadLines*(small?16:17);
      row.forEach((r,i)=>slotLayouts.push({r,tx:pad+i*(tileW+gap),ty:offset,tileW,tileH}));offset+=tileH+10;}
    offset+=25;
  }
  atlasGridH=Math.max(300,offset);atlasH=state.morph>.5?atlasGridH:baseH;svg.setAttribute('viewBox',`0 0 ${atlasW} ${atlasH}`);svg.style.height=`${atlasH}px`;
  append(svg,'title',{},'Garden State Parkway ramp shape collection');append(svg,'desc',{},'Original source geometry. Number, Parkway direction, ramp type and connecting road are shown for each shape. Tab to inspect a ramp or add it to the comparison.');
  $('atlasEmpty').hidden=atlasList.length>0;svg.hidden=!atlasList.length;
  $('atlasCount').textContent=`${atlasList.length} ${atlasList.length===1?'branch':'branches'} · ${new Set(atlasList.map(r=>r.group)).size} interchanges`;$('atlasCount').dataset.count=atlasList.length;
  document.querySelectorAll('[data-collection]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.collection===state.collection)));
  $('unfoldButton').disabled=!atlasList.length;$('saveAtlas').disabled=!atlasList.length;
  if(!atlasList.length){$('atlasViewLabel').textContent='No matching branches. Change a filter or collection.';return;}
  let corridor=state.section?countyCorridors[state.section]:{bounds:DATA.corridor_bounds,mainlines:DATA.corridor_mainlines};
  if(state.filters.group){const group=DATA.groups[state.filters.group];corridor={bounds:padBounds(group.bounds,.15,100),mainlines:group.context_lines.filter(l=>l.role==='mainline')};}
  const geoFit=fit(corridor.bounds,atlasW,baseH,{left:small?50:atlasW*.23,right:small?50:atlasW*.23,top:45,bottom:42});
  atlasGeoLayer=append(svg,'g',{'aria-hidden':'true'});drawBoundaryBackdrop(atlasGeoLayer,geoFit);const mainCol=document.body.classList.contains('night')?'#91ad90':'#8b9a87';
  for(const l of corridor.mainlines)append(atlasGeoLayer,'path',{d:xyPath(l.xy,geoFit),fill:'none',stroke:mainCol,'stroke-width':1.4,'stroke-linecap':'round','stroke-linejoin':'round','data-source-sri':l.sri});
  const labelPoints=!state.section&&!state.filters.group?countySections.filter(c=>atlasList.some(r=>COUNTY.by_group[r.group].primary===c.name)).map((c,i)=>({g:c.name,point:geoFit(c.label_point),side:i%2?-1:1})):groupOrder.filter(g=>atlasList.some(r=>r.group===g)).map((g,i)=>({g,point:geoFit(DATA.groups[g].center),side:i%2?-1:1}));
  for(const side of [-1,1]){const arr=labelPoints.filter(p=>p.side===side).sort((a,b)=>a.point[1]-b.point[1]),spacing=Math.min(25,(baseH-100)/Math.max(1,arr.length-1));let last=40-spacing;arr.forEach(p=>{p.y=Math.max(p.point[1],last+spacing);last=p.y;});for(let j=arr.length-1;j>=0;j--)arr[j].y=Math.min(arr[j].y,j===arr.length-1?baseH-44:arr[j+1].y-spacing);}
  for(const {g,point:p,side,y} of labelPoints){const x=clamp(p[0]+side*(small?40:65),small?42:95,atlasW-(small?42:95));append(atlasGeoLayer,'path',{d:`M${p[0]} ${p[1]}L${x-side*7} ${y}H${x}`,class:'geo-leader'});append(atlasGeoLayer,'text',{x:x+side*4,y:y+4,'text-anchor':side<0?'end':'start',class:'geo-label'},g);}
  append(atlasGeoLayer,'text',{x:atlasW-20,y:26,'text-anchor':'end',class:'atlas-corridor-label'},'N ↑');
  if(!small){append(atlasGeoLayer,'text',{x:18,y:35,'font-size':24,'letter-spacing':-.6},'Geographic position');append(atlasGeoLayer,'text',{x:18,y:60,class:'atlas-corridor-label'},'One shared geographic scale.');}
  append(atlasGeoLayer,'text',{x:small?10:18,y:baseH-14,class:'atlas-corridor-label'},'NJDOT centerlines · grid north up');
  atlasHeadingLayer=append(svg,'g',{'pointer-events':'none'});
  for(const h of sectionHeaders){const range=`${h.section.groups[0]}–${h.section.groups.at(-1)}`;append(atlasHeadingLayer,'text',{x:pad+8,y:h.y,class:'atlas-section-label'},h.section.label);append(atlasHeadingLayer,'text',{x:atlasW-pad-8,y:h.y,'text-anchor':'end',class:'atlas-section-meta'},`${h.count} ${h.count===1?'branch':'branches'}`);append(atlasHeadingLayer,'line',{x1:pad+8,x2:atlasW-pad-8,y1:h.y+12,y2:h.y+12,class:'atlas-divider'});}
  for(const {r,tx,ty,tileW,tileH} of slotLayouts){
    const bounds=sourceBounds(r),cx=(bounds[0]+bounds[2])/2,cy=(bounds[1]+bounds[3])/2,shapeH=small?132:140,tileScale=Math.min((tileW-40)/Math.max(1,bounds[2]-bounds[0]),(shapeH-17)/Math.max(1,bounds[3]-bounds[1])),tileCenter=[tx+tileW/2,ty+shapeH/2+9],gp=geoFit([cx,cy]);
    const root=append(svg,'g',{'data-atlas-root':r.fid}),g=append(root,'g',{class:'atlas-branch',role:'button',tabindex:0,'aria-label':`Inspect ${r.number}, ${movement(r)}, ${r.road}`,'aria-current':String(state.selected===r.fid),'data-fid':r.fid});
    const frame=append(g,'rect',{x:tx,y:ty,width:tileW,height:tileH-44,rx:3,class:'atlas-tile',opacity:state.morph});
    const transformed=append(g,'g'),d=xyPath(r.source_xy,p=>[p[0]-cx,cy-p[1]]);
    append(transformed,'path',{d,fill:'none',stroke:color(r,true),'stroke-width':3.2,'stroke-linecap':'round','stroke-linejoin':'round','vector-effect':'non-scaling-stroke',class:'atlas-line','data-source-sri':r.sri,'data-source-vertices':r.vertex_count});
    append(transformed,'path',{d,fill:'none',stroke:'transparent','stroke-width':20,'vector-effect':'non-scaling-stroke','pointer-events':'stroke',class:'ramp-hit'});
    const tracer=append(transformed,'circle',{fill:document.body.classList.contains('night')?'#fff6bf':'#18402d',class:'particle','pointer-events':'none'});
    const captionG=append(g,'g',{opacity:state.morph,'pointer-events':'none'}),y=ty+shapeH+34;
    append(captionG,'text',{x:tx+12,y,class:'atlas-number'},r.number);
    append(captionG,'text',{x:tx+12,y:y+22,class:'atlas-movement'},movement(r));
    svgMultiline(captionG,r.road,tx+12,y+43,tileW-24,{size:small?12:13,lineHeight:small?16:17});
    const cb=append(root,'g',{class:'atlas-compare',role:'button',tabindex:state.morph>.5?0:-1,'data-compare-fid':r.fid,'aria-label':`Add ${r.number}, ${movement(r)}, ${r.road} to comparison`,'aria-pressed':String(state.compare.includes(r.fid))});
    append(cb,'rect',{x:tx+8,y:ty+tileH-40,width:tileW-16,height:40,rx:3});append(cb,'text',{x:tx+16,y:ty+tileH-15},state.compare.includes(r.fid)?'✓ Added to pair':'+ Compare');
    const choose=e=>{e.stopPropagation();toggleCompare(r.fid);};cb.addEventListener('click',choose);cb.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();choose(e);}});
    const item={r,g,root,frame,transformed,captionG,tracer,compareButton:cb,cx,cy,map:{x:gp[0],y:gp[1],s:geoFit.s},tile:{x:tileCenter[0],y:tileCenter[1],s:tileScale},s:geoFit.s};atlasNodes.push(item);
    const inspect=()=>openDetail(r.fid,atlasList.map(x=>x.fid));g.addEventListener('click',inspect);g.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();inspect();}});
  }
  updateAtlasTransform(state.morph);updateAtlasLabels();renderAtlasFlows(state.time);
}
function updateAtlasTransform(t) {
  const h=mix(atlasBaseHeight(),atlasGridH,t),svg=$('atlasSVG');svg.setAttribute('viewBox',`0 0 ${atlasW} ${h}`);
  if(atlasGeoLayer)atlasGeoLayer.setAttribute('opacity',Math.pow(1-t,2));if(atlasHeadingLayer)atlasHeadingLayer.setAttribute('opacity',clamp((t-.5)*2));
  for(const a of atlasNodes){const s=mix(a.map.s,a.tile.s,t),x=mix(a.map.x,a.tile.x,t),y=mix(a.map.y,a.tile.y,t);a.s=s;a.transformed.setAttribute('transform',`translate(${x},${y}) scale(${s})`);a.captionG.setAttribute('opacity',clamp((t-.5)*2));a.frame.setAttribute('opacity',clamp((t-.2)/.8));a.frame.setAttribute('pointer-events',t>.5?'auto':'none');a.compareButton.setAttribute('opacity',clamp((t-.7)/.3));a.compareButton.setAttribute('pointer-events',t>.98?'auto':'none');a.compareButton.setAttribute('tabindex',t>.98?'0':'-1');a.compareButton.setAttribute('aria-hidden',t>.98?'false':'true');}
}
function updateAtlasLabels() {
  const unfolded=state.morph>.5;$('unfoldButton').querySelector('span').textContent=unfolded?'Place on corridor':'Unfold into shapes';$('unfoldButton').setAttribute('aria-expanded',String(unfolded));
  $('atlasViewLabel').textContent=unfolded?'Shape collection · individual scales · north up':'Geographic view · one shared scale · north up';
  $('atlasScaleNote').textContent=unfolded?'Each tile uses its own uniform scale. Use “Same scale” in a two-ramp comparison to compare size.':'The corridor uses one shared geographic scale.';
  $('atlasSVG').setAttribute('aria-label',unfolded?'Shape collection of selected ramp centerlines at individual uniform scales':'Selected ramp centerlines in geographic position at one common scale');
}
function resetFilters() {
  state.filters={group:'',direction:'',kind:''};refreshSharedControls();drawAtlas();
}
function openDetail(fid,ids=records.map(r=>r.fid)) {
  if(!byFID.has(fid))return;if(state.tour)toggleTour(false);
  if(!$('branchDialog').open)detailReturnFocus=document.activeElement;
  state.detailIDs=ids.includes(fid)?ids:records.map(r=>r.fid);state.detailIndex=state.detailIDs.indexOf(fid);state.trace=0;state.focus=false;state.detailVertices=false;$('detailVertices').checked=false;$('recordDisclosure').open=false;
  const r=byFID.get(fid);setGroup(r.group,{drawAtlas:false,preserveSelection:true});state.selected=fid;setSelectionDisplay();updateHighlight();
  paintDetail();document.body.classList.add('modal-open');if(!$('branchDialog').open)$('branchDialog').showModal();
}
function paintDetail() {
  const r=byFID.get(state.detailIDs[state.detailIndex]);if(!r)return;
  $('detailKicker').textContent=`${r.number} · ${movement(r)} · ${state.detailIndex+1} of ${state.detailIDs.length}`;$('detailTitle').textContent=r.road;
  const bounds=padBounds(sourceBounds(r),.09,100);detailScene=renderScene($('detailSVG'),[r],DATA.context_by_fid[r.fid],bounds,{width:700,height:485,mode:state.detailVertices?'vertices':'context',interactive:false,grid:false,detail:true,id:'detail'});
  for(const f of detailScene.flows)f.layer.remove();
  if(!state.detailVertices){const p=detailScene.project;append($('detailSVG'),'circle',{cx:p(r.source_xy[0])[0],cy:p(r.source_xy[0])[1],r:4,fill:'#f2eddc',stroke:'#243331','stroke-width':1});append($('detailSVG'),'circle',{cx:p(r.source_xy.at(-1))[0],cy:p(r.source_xy.at(-1))[1],r:4,fill:'#243331',stroke:'#f2eddc','stroke-width':1.5});}
  detailScene.tracer=append($('detailSVG'),'g',{class:'particle','aria-hidden':'true'});append(detailScene.tracer,'circle',{r:9,fill:'none',stroke:'#fff2b8','stroke-width':1,opacity:.6});append(detailScene.tracer,'circle',{r:4,fill:'#fff9d8'});
  $('detailReadHeader').innerHTML=`<strong>${esc(r.number)}</strong> · ${esc(r.kind)} branch`;
  $('detailMetrics').innerHTML=`<div><strong>${fmt(r.length_ft)} ft</strong><span>Length along the recorded line</span></div><div><strong>${esc(r.direction)}</strong><span>Direction on the Parkway</span></div>`;
  $('detailNote').textContent=r.note;const warning=warningFor(r);$('detailWarning').textContent=warning;$('detailWarning').hidden=!warning;
  const m=DATA.metrics_by_fid[r.fid],fields=[['Source selection',r.source_vertex_range?`US 9 excerpt · vertices ${r.source_vertex_range.start}–${r.source_vertex_range.end_inclusive} of ${r.source_vertex_range.total_source_vertices} (zero-based, inclusive)`:'Complete source feature'],['Source identifier',r.sri],['Source record',`FID ${sourceFID(r)}`],['Raw route name',r.source_attributes.SLD_NAME],['Raw direction',r.source_attributes.DIRECTION],['County association',groupCounties(r.group).join(' / ')+' (whole interchange; generalized boundaries)'],['Original vertices',String(r.vertex_count)],['Path / end-to-end',`${m.path_to_chord_ratio.toFixed(2)}× the straight-line endpoint distance`],['Snapshot','August 21, 2025'],['Coordinates','EPSG:3424 · NAD83 / New Jersey · US survey feet']];
  $('detailFields').innerHTML=fields.map(([k,v])=>`<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('');
  $('detailConnections').innerHTML=['start','end'].map(k=>{const n=DATA.endpoint_attachments[r.fid][k].nearest_eligible_context;return n?`<p><strong>Recorded ${k}:</strong> ${esc(n.name)}<br><code>${esc(n.sri)}</code> · FID ${n.fid}<br>Source gap: ${n.gap_ft<.000001?'0 (coordinate adjacency)':n.gap_ft.toFixed(8)+' US survey ft — retained, not snapped.'}${n.evidence?'<br>'+esc(n.evidence):''}</p>`:`<p class="source-warning"><strong>Recorded ${k}: open venue endpoint.</strong> No adjoining public-road centerline is represented. Internal venue or parking roads have not been invented.</p>`;}).join('');
  $('compareDetail').textContent=state.compare.includes(r.fid)?'✓ Added to pair':'+ Compare';$('compareDetail').setAttribute('aria-pressed',String(state.compare.includes(r.fid)));$('detailPointsKey').hidden=!state.detailVertices;
  $('traceProgress').value=String(Math.round(state.trace*1000));updateTrace();
}
function closeDetail() {
  $('branchDialog').close();document.body.classList.remove('modal-open');if(atlasDirty&&state.workspace==='atlas')drawAtlas();if(state.workspace==='explore')drawMain();
  const fid=state.detailIDs[state.detailIndex],replacement=state.workspace==='atlas'?$(`atlasSVG`)?.querySelector(`.atlas-branch[data-fid="${fid}"]`):$('branchList').querySelector(`[data-fid="${fid}"]`);
  if(detailReturnFocus?.isConnected)detailReturnFocus.focus({preventScroll:true});else replacement?.focus({preventScroll:true});
}
function toggleCompare(fid) {
  if(!byFID.has(fid))return;
  const present=state.compare.indexOf(fid);if(present>=0)state.compare[present]=null;else {const slot=state.compare.indexOf(null);if(slot<0){toast('Your pair is full. Open Compare to replace either ramp, or remove one from the tray.');return;}state.compare[slot]=fid;}
  updateComparisonUI();
}
function updateComparisonUI() {
  const list=state.compare.filter(Boolean),count=list.length;$('compareDock').hidden=count===0||['compare','design'].includes(state.workspace);document.body.classList.toggle('with-comparison-dock',count>0&&!$('compareDock').hidden);$('compareDockCount').textContent=`Compare · ${count}/2`;
  $('compareChips').innerHTML=state.compare.map((id,i)=>{if(!id)return '';const r=byFID.get(id);return `<div class="compare-chip"><span>${i===0?'A':'B'} · ${esc(r.number)}<small>${esc(movement(r))}</small></span><button data-remove-compare="${i}" aria-label="Remove ${esc(r.number)}, ${esc(movement(r))} from comparison">×</button></div>`;}).join('');
  $('compareChips').querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{state.compare[Number(b.dataset.removeCompare)]=null;updateComparisonUI();}));
  $('reviewComparison').textContent=count===2?'Compare pair ↗':'Choose second ramp ↗';
  document.querySelectorAll('[data-compare-fid]').forEach(b=>{const active=list.includes(Number(b.dataset.compareFid));b.setAttribute('aria-pressed',String(active));b.querySelector('text').textContent=active?'✓ Added to pair':'+ Compare';});
  setSelectionDisplay();if($('branchDialog').open){const r=byFID.get(state.detailIDs[state.detailIndex]);$('compareDetail').textContent=list.includes(r.fid)?'✓ Added to pair':'+ Compare';$('compareDetail').setAttribute('aria-pressed',String(list.includes(r.fid)));}
}

function openComparison() {
  if(state.tour)toggleTour(false);compareReturnFocus=document.activeElement;
  if($('branchDialog').open)closeDetail();
  if(!state.compare.some(Boolean)){state.compare=[5524,5725];state.compareExample=true;}else state.compareExample=false;
  document.querySelector('#compareDialog .dialog-header>div>span').textContent=state.compareExample?'Example pair · replace either ramp below':'Garden State Parkway · your selected source branches';
  document.body.classList.add('modal-open');$('compareDialog').showModal();updateComparisonUI();drawComparison();
}
function closeComparison() {
  $('compareDialog').close();document.body.classList.remove('modal-open');updateComparisonUI();if(compareReturnFocus?.isConnected)compareReturnFocus.focus({preventScroll:true});
}
function drawCompareShape(svg,r,scale,{w=520,h=350,light=true}={}) {
  svg.replaceChildren();svg.setAttribute('viewBox',`0 0 ${w} ${h}`);svg.style.aspectRatio=`${w} / ${h}`;
  if(!r){append(svg,'text',{x:w/2,y:h/2,'text-anchor':'middle',fill:getComputedStyle(document.body).getPropertyValue('--muted').trim(),'font-size':18},'Choose a ramp above');return null;}
  const b=sourceBounds(r),cx=(b[0]+b[2])/2,cy=(b[1]+b[3])/2,p=q=>[w/2+(q[0]-cx)*scale,(h-25)/2-(q[1]-cy)*scale];p.s=scale;
  const ink=getComputedStyle(document.body).getPropertyValue('--ink').trim(),muted=getComputedStyle(document.body).getPropertyValue('--muted').trim(),paper=getComputedStyle(document.body).getPropertyValue('--paper-2').trim();
  append(svg,'title',{},`${r.number}, ${movement(r)}, ${r.road}`);svg.setAttribute('aria-label',`${r.number}, ${movement(r)}, ${r.road}. ${state.compareScale==='same'?'Same scale as the other panel.':'Fitted independently to this panel.'}`);
  append(svg,'path',{d:xyPath(r.source_xy,p),fill:'none',stroke:color(r,light),'stroke-width':3.7,'stroke-linecap':'round','stroke-linejoin':'round','vector-effect':'non-scaling-stroke',class:'compare-line','data-source-sri':r.sri,'data-source-vertices':r.vertex_count});
  addStaticChevron(svg,r,p,true);const start=p(r.source_xy[0]),end=p(r.source_xy.at(-1));append(svg,'circle',{cx:start[0],cy:start[1],r:4,fill:ink,stroke:paper,'stroke-width':1.2});append(svg,'circle',{cx:end[0],cy:end[1],r:4,fill:paper,stroke:ink,'stroke-width':1.5});
  append(svg,'text',{x:w-15,y:24,'text-anchor':'end',fill:muted,'font-size':w<400?20:12},'N ↑');
  const units=[25,50,100,200,500,1000,2000,5000,10000].find(n=>n*scale>=38)||10000;
  append(svg,'path',{d:`M18 ${h-35}v4h${units*scale}v-4`,fill:'none',stroke:muted,'stroke-width':1,'vector-effect':'non-scaling-stroke'});append(svg,'text',{x:18,y:h-13,fill:muted,'font-size':w<400?19:11},`${fmt(units)} ft`);return p;
}
function drawComparison() {
  if(state.workspace!=='compare')return;
  const small=window.innerWidth<681,w=small?310:520,h=350,rs=state.compare.map(id=>byFID.get(id)),scales=rs.map(r=>r?Math.min((w-60)/Math.max(1,sourceBounds(r)[2]-sourceBounds(r)[0]),(h-83)/Math.max(1,sourceBounds(r)[3]-sourceBounds(r)[1])):Infinity),shared=Math.min(...scales);
  document.querySelectorAll('[data-compare-scale]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.compareScale===state.compareScale)));
  $('compareScaleDescription').textContent=state.compareScale==='same'?'Both panels use exactly the same scale. Differences in size and length stay visible.':'Each ramp is enlarged independently to fit its panel. Compare the shape—not the apparent size.';
  const displayFactors=rs.map((r,i)=>Math.max(.001,$('compareSVG'+i).clientWidth/w)),sharedPixels=Math.min(...scales.map((s,i)=>s*displayFactors[i]));
  compareProjects=[];
  rs.forEach((r,i)=>{const select=$(i?'compareB':'compareA');select.value=r?String(r.fid):'';for(const opt of select.options)opt.disabled=!!opt.value&&Number(opt.value)===state.compare[1-i];
    if(r){$('compareIdentity'+i).innerHTML=`<strong>${esc(r.number)}</strong><span>${esc(movement(r))}</span><h3>${esc(r.road)}</h3>`;$('compareMetrics'+i).innerHTML=`<div><strong>${fmt(r.length_ft)} ft</strong> along the line</div><span>${(r.length_ft/5280).toFixed(2)} miles</span>`;const warning=warningFor(r);$('compareNote'+i).textContent=warning||branchScope(r);$('compareNote'+i).classList.toggle('warning',!!warning);}
    else {$('compareIdentity'+i).innerHTML='<strong>—</strong><span>No ramp selected</span><h3>Choose a ramp to compare.</h3>';$('compareMetrics'+i).innerHTML='';$('compareNote'+i).textContent=`The chooser includes all ${records.length} branches, regardless of the current county filter.`;}
    const scale=state.compareScale==='same'?sharedPixels/displayFactors[i]:scales[i];compareProjects.push(drawCompareShape($('compareSVG'+i),r,scale,{w,h}));
  });$('saveComparison').disabled=rs.filter(Boolean).length!==2;
}
function exportComparison() {
  const rs=state.compare.map(id=>byFID.get(id));if(rs.some(r=>!r))return;
  const svg=node('svg',{xmlns:NS,viewBox:'0 0 1200 690',width:1200,height:690,id:'comparisonExport'}),ink=getComputedStyle(document.body).getPropertyValue('--ink').trim(),muted=getComputedStyle(document.body).getPropertyValue('--muted').trim(),paper=getComputedStyle(document.body).getPropertyValue('--paper').trim();
  svg.style.fontFamily='Arial, Helvetica, sans-serif';append(svg,'rect',{width:1200,height:690,fill:paper});append(svg,'text',{x:35,y:42,fill:ink,'font-size':26},'The shape of a turn · Garden State Parkway');append(svg,'text',{x:35,y:72,fill:muted,'font-size':14},state.compareScale==='same'?'Same geographic scale in both panels · grid north up':'Each shape fitted separately · individual uniform scales · grid north up');
  const w=540,h=370,scales=rs.map(r=>Math.min((w-65)/(sourceBounds(r)[2]-sourceBounds(r)[0]||1),(h-83)/(sourceBounds(r)[3]-sourceBounds(r)[1]||1))),common=Math.min(...scales);
  rs.forEach((r,i)=>{const x=35+i*600;append(svg,'text',{x,y:119,fill:ink,'font-size':31},r.number);append(svg,'text',{x:x+115,y:116,fill:muted,'font-size':15},movement(r));svgMultiline(svg,r.road,x,148,525,{size:15,lineHeight:19,className:'export-road',fill:ink});const sub=append(svg,'svg',{x,y:190,width:w,height:h});drawCompareShape(sub,r,state.compareScale==='same'?common:scales[i],{w,h});append(svg,'text',{x,y:587,fill:ink,'font-size':18},`${fmt(r.length_ft)} ft along the recorded line`);append(svg,'text',{x,y:612,fill:muted,'font-size':11},`FID ${sourceFID(r)} · ${r.sri}`);});
  append(svg,'text',{x:35,y:657,fill:muted,'font-size':12},'NJDOT centerline snapshot · 21 August 2025 · Selected source branches, not complete trips. Width is illustrative.');
  append(svg,'metadata',{},JSON.stringify({source:DATA.provenance.official_source_url,snapshot:'2025-08-21',crs:DATA.crs,comparison_scale:state.compareScale,transformation:'Translation and uniform scaling only; no rotation, smoothing or stretching.',records:rs.map(r=>({fid:sourceFID(r),selection_key:r.fid,source_fid:sourceFID(r),source_vertex_range:r.source_vertex_range||null,source_selection:r.source_selection||'complete_feature',sri:r.sri,number:r.number,kind:r.kind,direction:r.direction,road:r.road,source_xy:r.source_xy,note:r.note,warning:warningFor(r)}))}));
  save(`GSP_Compare_${rs[0].number}_${rs[1].number}_${state.compareScale}_scale.svg`,'<?xml version="1.0" encoding="UTF-8"?>\n'+new XMLSerializer().serializeToString(svg),'image/svg+xml');
}
function tick(timestamp) {
  const dt=lastTick?Math.min(.12,(timestamp-lastTick)/1000):0;lastTick=timestamp;
  const modal=$('branchDialog').open||(state.workspace==='compare');
  if(!document.hidden&&state.playing&&!modal){state.time+=dt*state.speed;if(state.workspace==='explore'&&sceneVisible)renderFlows(mainFlows,state.time);if(state.workspace==='atlas'&&atlasVisible)renderAtlasFlows(state.time);}
  if(state.morphAnimation){const a=state.morphAnimation,t=clamp((timestamp-a.start)/a.duration),e=t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;state.morph=mix(a.from,a.to,e);updateAtlasTransform(state.morph);renderAtlasFlows(state.time);if(t===1){state.morphAnimation=null;updateAtlasLabels();}}
  if(state.tour&&!document.hidden&&!modal){state.tourElapsed+=dt;if(state.tourElapsed>=6.5){state.tourElapsed=0;const tourGroups=scopedGroups(),next=tourGroups.indexOf(state.group)+1;if(next>=tourGroups.length){toggleTour(false);toast('The corridor tour is complete.');}else setGroup(tourGroups[next],{fromTour:true,scrollNav:true});}}
  requestAnimationFrame(tick);
}
function init() {
  $('sectionSelect').innerHTML='<option value="">Full Parkway · 172–0</option>'+countySections.map(c=>`<option value="${c.id}">${c.label}</option>`).join('');$('sectionSelect').addEventListener('change',()=>setSharedSection($('sectionSelect').value));
  document.querySelectorAll('[data-workspace]').forEach(b=>b.addEventListener('click',()=>switchWorkspace(b.dataset.workspace)));
  document.querySelectorAll('a[href="#explore"],a[href="#atlas"]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();switchWorkspace(a.getAttribute('href')==='#atlas'?'atlas':'explore',{scroll:true});}));
  $('currentExitLink').addEventListener('click',()=>switchWorkspace('explore'));
  $('previousGroup').addEventListener('click',()=>stepGroup(-1));$('nextGroup').addEventListener('click',()=>stepGroup(1));
  $('exitSearch').addEventListener('input',updateSearch);$('exitSearch').addEventListener('focus',()=>{clearTimeout(searchCloseTimer);if($('exitSearch').value)updateSearch();});
  $('exitSearch').addEventListener('keydown',e=>{if(e.key==='Escape'){closeSearch();return;}if(['ArrowDown','ArrowUp'].includes(e.key)&&searchItems.length){e.preventDefault();searchActive=(searchActive+(e.key==='ArrowDown'?1:-1)+searchItems.length)%searchItems.length;$('searchPanel').hidden=false;$('exitSearch').setAttribute('aria-expanded','true');$('exitSearch').setAttribute('aria-activedescendant',`search-option-${searchActive}`);$('searchResults').querySelectorAll('[role=option]').forEach((n,i)=>n.setAttribute('aria-selected',String(i===searchActive)));$(`search-option-${searchActive}`).scrollIntoView({block:'nearest'});}if(e.key==='Enter'&&!$('searchPanel').hidden){e.preventDefault();chooseSearch(searchActive>=0?searchActive:0);}});
  document.addEventListener('pointerdown',e=>{if(!e.target.closest('.search-shell'))closeSearch();});$('exitSearch').addEventListener('blur',()=>{clearTimeout(searchCloseTimer);searchCloseTimer=setTimeout(()=>{if(!document.activeElement?.closest('.search-shell'))closeSearch();},120);});
  document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>{state.view=b.dataset.view;drawMain();}));
  document.querySelectorAll('[data-collection]').forEach(b=>b.addEventListener('click',()=>{state.collection=b.dataset.collection;drawAtlas();}));
  $('filterGroup').addEventListener('change',()=>{const g=$('filterGroup').value;state.filters.group=g;if(g)setGroup(g,{drawAtlas:false});refreshSharedControls();drawAtlas();});
  $('filterDirection').addEventListener('change',()=>{state.filters.direction=$('filterDirection').value;drawAtlas();});$('filterKind').addEventListener('change',()=>{state.filters.kind=$('filterKind').value;drawAtlas();});
  $('resetFilters').addEventListener('click',resetFilters);$('unfoldButton').addEventListener('click',()=>setMorph(state.morphAnimation?1-state.morphAnimation.to:state.morph>.5?0:1));
  $('clearBranch').addEventListener('click',()=>{if(state.selected)selectBranch(state.selected);});$('focusBranch').addEventListener('click',()=>{if(state.selected){state.focus=!state.focus;drawMain();}});$('inspectSelected').addEventListener('click',()=>{if(state.selected)openDetail(state.selected,DATA.groups[state.group].fids);});
  $('compareSelected').addEventListener('click',()=>{if(state.selected)toggleCompare(state.selected);});$('compareDetail').addEventListener('click',()=>toggleCompare(state.detailIDs[state.detailIndex]));
  $('viewDetailInterchange').addEventListener('click',()=>{const r=byFID.get(state.detailIDs[state.detailIndex]);closeDetail();setGroup(r.group,{drawAtlas:false});state.selected=r.fid;state.focus=false;switchWorkspace('explore',{scroll:true});});
  $('motionToggle').addEventListener('click',()=>setPlaying(!state.playing));$('flowSpeed').addEventListener('change',()=>state.speed=Number($('flowSpeed').value));$('tourToggle').addEventListener('click',()=>toggleTour());
  $('themeToggle').addEventListener('click',()=>{document.body.classList.toggle('night');const night=document.body.classList.contains('night');$('themeToggle').setAttribute('aria-label',night?'Switch to paper mode':'Switch to night mode');$('themeToggle').title=night?'Switch to paper mode':'Switch to night mode';drawAtlas();drawComparison();});
  function expandedLabel(){const yes=!!document.fullscreenElement||$('stageShell').classList.contains('expanded');$('fullScreen').setAttribute('aria-label',yes?'Exit expanded map':'Expand map');requestAnimationFrame(drawMain);}
  $('fullScreen').addEventListener('click',async()=>{const el=$('stageShell');try{if(document.fullscreenElement)await document.exitFullscreen();else if(el.classList.contains('expanded'))el.classList.remove('expanded');else if(el.requestFullscreen)await el.requestFullscreen();else el.classList.add('expanded');}catch(e){el.classList.toggle('expanded');}expandedLabel();});document.addEventListener('fullscreenchange',expandedLabel);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){if($('stageShell').classList.contains('expanded')){$('stageShell').classList.remove('expanded');expandedLabel();}if(state.tour)toggleTour(false);}if(e.key===' '&&e.target===document.body){e.preventDefault();setPlaying(!state.playing);}});
  $('closeDetail').addEventListener('click',closeDetail);$('branchDialog').addEventListener('cancel',e=>{e.preventDefault();closeDetail();});$('branchDialog').addEventListener('close',()=>document.body.classList.remove('modal-open'));
  $('branchDialog').addEventListener('click',e=>{if(e.target===$('branchDialog')){const b=$('branchDialog').getBoundingClientRect();if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom)closeDetail();}});
  for(const [id,step] of [['previousDetail',-1],['nextDetail',1]])$(id).addEventListener('click',()=>{state.detailIndex=(state.detailIndex+step+state.detailIDs.length)%state.detailIDs.length;state.trace=0;const r=byFID.get(state.detailIDs[state.detailIndex]);setGroup(r.group,{drawAtlas:false,preserveSelection:true});state.selected=r.fid;setSelectionDisplay();updateHighlight();paintDetail();});
  $('detailVertices').addEventListener('change',()=>{state.detailVertices=$('detailVertices').checked;paintDetail();});$('traceProgress').addEventListener('input',()=>{state.trace=Number($('traceProgress').value)/1000;updateTrace();});
  $('saveBranch').addEventListener('click',()=>{const r=byFID.get(state.detailIDs[state.detailIndex]);saveSVG($('detailSVG'),`GSP_${r.number}_${r.kind}_${r.direction}_${r.fid}.svg`,[r]);});
  $('saveStage').addEventListener('click',()=>saveSVG($('mainSVG'),`GSP_${state.group}${state.focus?'_focused':''}_interchange.svg`,state.focus?[byFID.get(state.selected)]:DATA.groups[state.group].fids.map(id=>byFID.get(id))));
  $('saveAtlas').addEventListener('click',()=>{if(atlasList.length)saveSVG($('atlasSVG'),`GSP_${state.collection}_${atlasList.length}_${state.morph>.5?'shapes':'geography'}.svg`,atlasList);});
  $('saveCSV').addEventListener('click',saveCSV);$('saveCoordinates').addEventListener('click',()=>save('GSP_exact_source_coordinates.json',JSON.stringify({crs:DATA.crs,provenance:DATA.provenance,audit:DATA.audit,records},null,2),'application/json'));$('saveGeoJSON').addEventListener('click',()=>save('GSP_selected_ramps_WGS84.geojson',JSON.stringify(DATA.geojson),'application/geo+json'));
  $('openComparison').addEventListener('click',openComparison);$('reviewComparison').addEventListener('click',openComparison);$('closeComparison').addEventListener('click',closeComparison);
  $('clearComparison').addEventListener('click',()=>{state.compare=[null,null];updateComparisonUI();});
  const opts=comparisonOptionHTML();['compareA','compareB'].forEach((id,i)=>{$(id).innerHTML=opts;$(id).addEventListener('change',()=>{const next=$(id).value?Number($(id).value):null;if(next&&state.compare[1-i]===next){toast('Choose two different branches.');drawComparison();return;}state.compare[i]=next;updateComparisonUI();drawComparison();});});
  document.querySelectorAll('[data-compare-scale]').forEach(b=>b.addEventListener('click',()=>{state.compareScale=b.dataset.compareScale;drawComparison();}));$('saveComparison').addEventListener('click',exportComparison);
  reduced.addEventListener('change',e=>{if(e.matches){setPlaying(false);if(state.morphAnimation)setMorph(state.morphAnimation.to,{animate:false});}});
  window.addEventListener('resize',()=>{clearTimeout(renderTimer);renderTimer=setTimeout(()=>{state.morphAnimation=null;state.morph=state.morph>.5?1:0;drawMain();drawAtlas();drawComparison();},160);});
  document.addEventListener('visibilitychange',()=>lastTick=0);
  if('IntersectionObserver' in window){const observer=new IntersectionObserver(es=>es.forEach(e=>{if(e.target.id==='stageShell')sceneVisible=e.isIntersecting;if(e.target.id==='atlasCanvas')atlasVisible=e.isIntersecting;}),{rootMargin:'150px'});observer.observe($('stageShell'));observer.observe($('atlasCanvas'));}
  populateSources();setPlaying(state.playing);setGroup(state.group,{drawAtlas:false});updateComparisonUI();switchWorkspace('overview');requestAnimationFrame(tick);
}
/* Parkway display layer. Source coordinates and record labels are read-only. */
// Selection starts empty; no southern-batch override.
let relatedGroup=null;
const token = name => getComputedStyle(document.body).getPropertyValue(name).trim();

// The restrained road-sign palette is a display treatment, not a sign specification.
color = function(r,light=false) {
  return token(r.kind==='Exit'?(light?'--exit-on-paper':'--exit'):(light?'--entrance-on-paper':'--entrance'));
};
contextStyle = function(role,mode) {
  if(role==='mainline')return {w:4.4,ink:'#abb9b1',opacity:mode==='clean'?.25:.9};
  if(role==='connector')return {w:2.5,ink:'#899d92',opacity:mode==='clean'?.12:.64};
  return {w:.85,ink:'#91a499',opacity:mode==='clean'?0:.22};
};
const baseSelectionDisplay = setSelectionDisplay;
setSelectionDisplay = function() {
  baseSelectionDisplay();
  const r=byFID.get(state.selected),list=DATA.groups[state.group].fids.map(id=>byFID.get(id));
  $('quickDetailContent').hidden=!r;$('quickDetailEmpty').hidden=!!r;$('quickTrace').disabled=!r;
  if(!r){$('quickGroupTitle').textContent=`Interchange ${state.group}`;$('quickGroupRoad').textContent=groupNames[state.group];}
  if(r){
    $('quickType').textContent=movement(r);$('quickType').classList.toggle('entrance',r.kind==='Entrance');
    $('quickTitle').textContent=numberTitle(r);$('quickRoad').textContent=r.road;
    $('quickMetrics').innerHTML=[['Type',r.kind],['Direction',r.direction],['Length',`${fmt(r.length_ft)} ft`]].map(([k,v])=>`<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join('');
    $('quickNote').textContent=branchScope(r);
  }
  document.querySelectorAll('.ramp-thumb').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.fid)===state.selected)));
};
const baseSetGroup=setGroup;
setGroup = function(g,options={}) {
  if(!DATA.groups[g])return;
  baseSetGroup(g,options);
  renderRelated();
};
function renderRelated(){
  if(relatedGroup===state.group)return;relatedGroup=state.group;
  const rs=DATA.groups[state.group].fids.map(id=>byFID.get(id));
  $('relatedHeading').textContent=`Ramps at interchange ${state.group}`;
  $('relatedCount').textContent=`${rs.length} selected branches`;
  $('relatedGrid').replaceChildren();
  for(const r of rs){
    const b=document.createElement('button');b.className='ramp-thumb';b.dataset.fid=r.fid;b.setAttribute('aria-pressed',String(state.selected===r.fid));b.setAttribute('aria-label',`${r.number}, ${movement(r)}, ${r.road}`);
    const s=node('svg',{viewBox:'0 0 170 95','aria-hidden':'true'}),p=fit(sourceBounds(r),170,95,12);
    append(s,'path',{d:xyPath(r.source_xy,p),fill:'none',stroke:color(r,true),'stroke-width':2.6,'stroke-linecap':'round','stroke-linejoin':'round','data-source-sri':r.sri});b.append(s);
    const strong=document.createElement('strong');strong.textContent=r.number;b.append(strong);
    const desc=document.createElement('span');desc.textContent=movement(r);b.append(desc);
    const road=document.createElement('small');road.textContent=r.road;b.append(road);
    b.addEventListener('click',()=>{state.selected=r.fid;state.focus=false;setSelectionDisplay();drawMain();$('stageShell').scrollIntoView({behavior:reduced.matches?'auto':'smooth',block:'start'});});
    $('relatedGrid').append(b);
  }
}

const baseAtlas=drawAtlas;
drawAtlas = function(){baseAtlas();if(state.workspace==='atlas')drawCollectionLocator();};

// Comparison is now a full workspace, not another overlay.

openComparison = function(){
  if(state.tour)toggleTour(false);
  compareReturnFocus=document.activeElement;
  if($('branchDialog').open)closeDetail();
  if(!state.compare.some(Boolean)){state.compare=[5524,5725];state.compareExample=true;}else state.compareExample=false;
  document.querySelector('#compareDialog .dialog-header>div>span').textContent=state.compareExample?'Example pair · choose any two branches':'Selected source branches';
  switchWorkspace('compare',{scroll:false});
};
closeComparison = function(){switchWorkspace('explore');$('openComparison').focus({preventScroll:true});};

// Source paths are translated and uniformly scaled; background roads use the same projection.
drawCompareShape = function(svg,r,scale,{w=520,h=350,light=false}={}){
  svg.replaceChildren();svg.setAttribute('viewBox',`0 0 ${w} ${h}`);svg.style.aspectRatio=`${w} / ${h}`;
  append(svg,'rect',{width:w,height:h,fill:token('--stage')});
  if(!r){append(svg,'text',{x:w/2,y:h/2,'text-anchor':'middle',fill:'#e7eee7','font-size':w<400?21:17},'Choose a ramp above');return null;}
  const b=sourceBounds(r),cx=(b[0]+b[2])/2,cy=(b[1]+b[3])/2,p=q=>[w/2+(q[0]-cx)*scale,(h-25)/2-(q[1]-cy)*scale];p.s=scale;
  append(svg,'title',{},`${r.number}, ${movement(r)}, ${r.road}`);
  svg.setAttribute('aria-label',`${r.number}, ${movement(r)}, ${r.road}. ${state.compareScale==='same'?'Same scale as the other panel.':'Fitted independently to this panel.'}`);
  const uid=`clip-${svg.id||('export-'+r.fid)}`,defs=append(svg,'defs'),clip=append(defs,'clipPath',{id:uid});append(clip,'rect',{x:8,y:30,width:w-16,height:h-83});
  if(state.compareContext){
    const ctx=append(svg,'g',{'clip-path':`url(#${uid})`,'aria-hidden':'true'});
    for(const l of DATA.context_by_fid[r.fid]||[]){if(l.fid===sourceFID(r)&&!l.source_remainder)continue;const st=contextStyle(l.role,'context');append(ctx,'path',{d:xyPath(l.xy,p),fill:'none',stroke:st.ink,'stroke-width':l.role==='mainline'?3:1.3,'stroke-opacity':l.role==='local'?.15:.35,'stroke-linecap':'round','stroke-linejoin':'round','vector-effect':'non-scaling-stroke','data-source-sri':l.sri});}
  }
  append(svg,'path',{d:xyPath(r.source_xy,p),fill:'none',stroke:color(r),'stroke-width':3.9,'stroke-linecap':'round','stroke-linejoin':'round','vector-effect':'non-scaling-stroke',class:'compare-line','data-source-sri':r.sri,'data-source-vertices':r.vertex_count});
  addStaticChevron(svg,r,p,false);
  const start=p(r.source_xy[0]),end=p(r.source_xy.at(-1));
  append(svg,'circle',{cx:start[0],cy:start[1],r:4,fill:'#faf7df',stroke:token('--stage'),'stroke-width':1.2});append(svg,'circle',{cx:end[0],cy:end[1],r:4,fill:token('--stage'),stroke:'#faf7df','stroke-width':1.5});
  append(svg,'text',{x:w-15,y:23,'text-anchor':'end',fill:'#d4e0d7','font-size':w<400?21:12},'N ↑');
  const units=[10,25,50,100,200,500,1000,2000,5000,10000].find(n=>n*scale>=38)||10000;
  append(svg,'path',{d:`M18 ${h-35}v4h${units*scale}v-4`,fill:'none',stroke:'#cad8ce','stroke-width':1,'vector-effect':'non-scaling-stroke'});
  append(svg,'text',{x:18,y:h-13,fill:'#cad8ce','font-size':w<400?19:11},`${fmt(units)} ft`);
  return p;
};
const baseComparison=drawComparison;
drawComparison = function(){
  baseComparison();if(state.workspace!=='compare')return;
  $('compareContext').checked=state.compareContext;
  const rs=state.compare.map(id=>byFID.get(id));
  if(rs.every(Boolean)){
    const diff=rs[1].length_ft-rs[0].length_ft;
    $('comparisonDifference').textContent=`Ramp ${diff>=0?'B':'A'} (${diff>=0?rs[1].number:rs[0].number}) is ${fmt(Math.abs(diff))} ft longer along its recorded centerline.`;
  }else $('comparisonDifference').textContent='Select two different branches to compare their shapes and measured centerline lengths.';
  rs.forEach((r,i)=>{$('compareContext'+i).disabled=!r;$('compareContext'+i).textContent=r?`View interchange ${r.group} →`:'View interchange';});
};
function openComparedInterchange(i){
  const r=byFID.get(state.compare[i]);if(!r)return;setGroup(r.group,{drawAtlas:false});state.selected=r.fid;state.focus=false;switchWorkspace('explore');setSelectionDisplay();drawMain();
}
function initParkway(){
  $('compareContext').addEventListener('change',()=>{state.compareContext=$('compareContext').checked;drawComparison();});
  $('compareContext0').addEventListener('click',()=>openComparedInterchange(0));$('compareContext1').addEventListener('click',()=>openComparedInterchange(1));
  $('quickTrace').addEventListener('click',()=>{if(state.selected)openDetail(state.selected,DATA.groups[state.group].fids);});
  document.querySelectorAll('[data-open-design]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();switchWorkspace('design',{scroll:true});}));
  document.querySelectorAll('[data-open-method],[data-open-sources]').forEach(a=>a.addEventListener('click',()=>{if(state.workspace==='design')switchWorkspace('explore');}));
  document.querySelectorAll('[data-save-tokens]').forEach(b=>b.addEventListener('click',()=>save('parkway-tokens.css',document.getElementById('parkway-tokens').textContent,'text/css;charset=utf-8')));
  $('relatedBrowse').addEventListener('click',()=>{state.collection='all';state.filters={group:state.group,direction:'',kind:''};switchWorkspace('atlas');});
  $('themeToggle').addEventListener('click',()=>{relatedGroup=null;renderRelated();drawLocator();setGroup(state.group,{drawAtlas:false,preserveSelection:true});drawCollectionLocator();drawMain();});
  renderRelated();setSelectionDisplay();
  // Display is usable as a local file; no network map layers or font services are required.
}

/* County browsing uses a separate, auditable geographic layer. The roadway JSON is untouched. */
function areaLabel(id=state.section){return id?countyById.get(id).label:'Full Parkway';}
function groupCounties(g){return COUNTY.by_group[g].counties;}
function scopedGroups(){return sectionGroups(state.section);}
function stableGroup(g){return DATA.groups[g]&&scopedGroups().includes(g);}
function countyForName(name){return countySections.find(c=>c.name===name);}
function groupLabel(g){return `${g==='12'?'Access':'Exit'} ${g}`;}
function polygonPath(geom,project){
  const polygons=geom.type==='Polygon'?[geom.coordinates]:geom.coordinates;
  return polygons.map(poly=>poly.map(r=>xyPath(r,project)+' Z').join(' ')).join(' ');
}
function drawBoundaryBackdrop(svg,project,{selected=state.section,land=true}={}){
  const layer=append(svg,'g',{'aria-hidden':'true',class:'county-backdrop'});
  if(land)append(layer,'path',{d:polygonPath(COUNTY.land,project),class:'overview-land','fill-rule':'evenodd'});
  for(const c of countySections)append(layer,'path',{d:polygonPath(c.geometry,project),class:'overview-county'+(c.id===selected?' is-active':''),'fill-rule':'evenodd','data-county-outline':c.id});
  return layer;
}
function renderExitNav(){
  const restoreFocus=$('exitNav').contains(document.activeElement)&&document.activeElement?.matches('[data-group]');
  const gs=scopedGroups();$('navDirection').innerHTML=`<b>${esc(state.section?countyById.get(state.section).name:'172–0')}</b>North → south`;
  $('exitNav').innerHTML=gs.map(g=>`<button data-group="${g}" aria-pressed="${g===state.group}" title="${esc(groupNames[g])}" aria-label="${groupLabel(g)}, ${esc(groupNames[g])}">${g}</button>`).join('');
  $('exitNav').querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>setGroup(b.dataset.group)));
  $('exitJump').innerHTML=gs.map(g=>`<option value="${g}">${groupLabel(g)} · ${esc(groupNames[g])}</option>`).join('');$('exitJump').value=state.group;
  centerExitNav(false);
  if(restoreFocus)$('exitNav').querySelector(`[data-group="${state.group}"]`)?.focus({preventScroll:true});
}
function centerExitNav(smooth=false){
 const nav=$('exitNav'),btn=nav.querySelector(`[data-group="${state.group}"]`);if(!btn)return;
 const left=btn.offsetLeft-nav.offsetLeft-nav.clientWidth/2+btn.clientWidth/2;
 nav.scrollTo({left:Math.max(0,left),behavior:smooth&&!reduced.matches?'smooth':'instant'});
}
function refreshSharedControls(){
  $('sectionSelect').value=state.section;
  const gs=scopedGroups(),rs=records.filter(r=>gs.includes(r.group));
  $('sectionStatus').textContent=`${gs.length} access groups · ${rs.length} selected paths`;
  const counts={all:rs.length,featured:rs.filter(r=>FEATURED_FIDS.has(r.fid)).length,signature:rs.filter(r=>r.overview_order!==null).length};
  document.querySelectorAll('[data-collection]').forEach(b=>{const k=b.dataset.collection;b.textContent=k==='all'?`All ${counts[k]} paths`:`${counts[k]} ${k==='featured'?'featured':'representative'}`;b.title=`Available in ${areaLabel()} before the direction, interchange and ramp-type filters`;});
  $('currentExitLink').textContent=`${groupLabel(state.group)} · ${groupNames[state.group]}`;
  $('filterGroup').innerHTML='<option value="">All interchanges in this area</option>'+gs.map(g=>`<option value="${g}">${g} · ${esc(groupNames[g])}</option>`).join('');
  $('filterGroup').value=state.filters.group;$('filterDirection').value=state.filters.direction;$('filterKind').value=state.filters.kind;
  const index=gs.indexOf(state.group),canStep=state.workspace==='explore';
  document.querySelector('.corridor-steps').hidden=!canStep;
  $('groupTotal').textContent=gs.length;$('groupPosition').textContent=String(index+1).padStart(2,'0');
  $('previousGroup').disabled=!canStep||index<=0;$('nextGroup').disabled=!canStep||index<0||index===gs.length-1;
  $('previousGroup').setAttribute('aria-label',`Previous interchange north in ${areaLabel()}`);$('nextGroup').setAttribute('aria-label',`Next interchange south in ${areaLabel()}`);
  $('sectionSelect').disabled=['compare','design'].includes(state.workspace);
  $('resetScope').hidden=!state.section;
  const cross=groupCounties(state.group);
  $('interchangeCounty').textContent=cross.length>1?`Border connection · ${cross.join(' / ')} counties`:cross[0]+' County';
  $('interchangeCounty').classList.toggle('border-connection',cross.length>1);
  $('scopeNotice').textContent=state.section&&gs.some(g=>groupCounties(g).length>1)?'Border connections stay whole and may also appear under a neighboring county.':'';
  $('scopeNotice').hidden=!$('scopeNotice').textContent;
}
function setSharedSection(id){
  if(id&&!countyById.has(id))return;
  const overviewFocus=state.workspace==='overview'&&($('overviewDirectory').contains(document.activeElement)||$('overviewSVG').contains(document.activeElement));
  if(state.tour)toggleTour(false);
  state.section=id;const gs=scopedGroups();
  if(state.filters.group&&!gs.includes(state.filters.group))state.filters.group='';
  if(!gs.includes(state.group)){
    state.selected=null;state.focus=false;state.hover=null;
    setGroup(gs.includes(state.lastBySection[id])?state.lastBySection[id]:gs[0],{drawAtlas:false});
  }
  refreshSharedControls();renderExitNav();drawLocator();atlasDirty=true;
  if(state.workspace==='overview'){drawOverview();if(overviewFocus){$('overviewTitle').tabIndex=-1;$('overviewTitle').focus({preventScroll:true});}}
  if(state.workspace==='atlas')drawAtlas();
  if(state.workspace==='explore')drawMain();
}
function resetToFull({overview=true}={}){
 if(state.tour)toggleTour(false);
 state.filters={group:'',direction:'',kind:''};state.section='';state.selected=null;state.focus=false;state.hover=null;
 setGroup(groupOrder[0],{drawAtlas:false});
 if(overview)switchWorkspace('overview');else {refreshSharedControls();if(state.workspace==='atlas')drawAtlas();}
}
function stepGroup(step){
 const gs=scopedGroups(),i=gs.indexOf(state.group),next=gs[i+step];if(next)setGroup(next,{scrollNav:true});
}
function drawOverview(){
 if(state.workspace!=='overview')return;
 const c=countyById.get(state.section),gs=scopedGroups(),rs=records.filter(r=>gs.includes(r.group));
 $('overviewTitle').textContent=c?c.label:'The full Parkway';
 $('overviewMeta').textContent=c?`${gs.length} access groups · ${rs.length} selected paths`:`172 to 0 · ${countySections.length} counties · ${groupOrder.length} access groups · ${records.length} selected paths`;
 $('overviewBack').hidden=!c;$('overviewDirectoryTitle').textContent=c?'Choose an interchange':'Browse by county';
 $('overviewDirectoryNote').textContent=c?'North to south. Border connections remain intact.':'North to south. Select a county for a closer view.';
 $('overviewBoundaryNote').textContent='County outlines are generalized for browsing. Ramp geometry remains the August 2025 NJDOT source.';
 $('countyCountNote').hidden=!!c;
 const directory=$('overviewDirectory');directory.replaceChildren();
 if(!c){
  for(const county of countySections){
   const b=document.createElement('button');b.className='county-directory-row';b.dataset.county=county.id;
   b.innerHTML=`<span><strong>${esc(county.name)}</strong><small>${county.groups.length} access groups · ${county.record_count} selected paths</small></span><span class="directory-range">${county.groups[0]}–${county.groups.at(-1)} <span aria-hidden="true">→</span></span>`;
   b.addEventListener('click',()=>setSharedSection(county.id));directory.append(b);
  }
 }else{
  for(const g of gs){
   const b=document.createElement('button');b.className='county-directory-row interchange-directory-row';b.dataset.overviewGroup=g;
   const names=groupCounties(g);
   b.innerHTML=`<span class="directory-number">${g}</span><span><strong>${esc(groupNames[g])}</strong><small>${g==='12'?'Entrance-only access · ':''}${DATA.groups[g].fids.length} selected paths${names.length>1?' · '+names.join(' / '):''}</small></span><span aria-hidden="true">→</span>`;
   b.addEventListener('click',()=>openOverviewGroup(g));directory.append(b);
  }
 }
 const svg=$('overviewSVG'),width=Math.max(280,$('overviewMap').clientWidth),small=innerWidth<681,height=small?430:665;
 svg.replaceChildren();svg.setAttribute('viewBox',`0 0 ${width} ${height}`);
 append(svg,'title',{},c?`${c.label}: Parkway interchanges`:'Garden State Parkway, full corridor and counties');
 append(svg,'desc',{},'County outlines provide geographic context. The directory beside or below the map provides the same county and interchange selections.');
 const bounds=c?padBounds(c.bounds,.12,2200):COUNTY.full_bounds;
 const p=fit(bounds,width,height,{left:small?26:65,right:small?26:65,top:35,bottom:35});
 drawBoundaryBackdrop(svg,p);
 const roads=append(svg,'g',{'aria-hidden':'true'});
 const clips=append(append(svg,'defs'),'clipPath',{id:'overview-frame'});append(clips,'rect',{x:8,y:8,width:width-16,height:height-16});roads.setAttribute('clip-path','url(#overview-frame)');
 for(const l of DATA.corridor_mainlines)append(roads,'path',{d:xyPath(l.xy,p),class:'overview-route is-background'});
 for(const l of c?c.mainlines:DATA.corridor_mainlines)append(roads,'path',{d:xyPath(l.xy,p),class:'overview-route'});
 if(!c){
   const labels=countySections.map((county,i)=>({county,point:p(county.label_point),side:i%2?-1:1}));
   for(const side of [-1,1]){
     const same=labels.filter(x=>x.side===side).sort((a,b)=>a.point[1]-b.point[1]);let y=30;
     for(const l of same){l.y=Math.max(l.point[1],y);y=l.y+(small?29:39);}
     for(let i=same.length-1;i>=0;i--)same[i].y=Math.min(same[i].y,i===same.length-1?height-32:same[i+1].y-(small?29:39));
   }
   for(const {county,point:q,side,y} of labels){
     const labelW=small?82:105,x=side<0?Math.max(8,q[0]-labelW-28):Math.min(width-labelW-8,q[0]+30);
     const g=append(svg,'g',{role:'button',tabindex:0,class:'overview-map-control','aria-label':`Browse ${county.label}`,'data-map-county':county.id});
     append(g,'path',{d:`M${q[0]} ${q[1]}L${side<0?x+labelW:x} ${y}`,class:'overview-leader'});
     append(g,'rect',{x,y:y-17,width:labelW,height:34,rx:4,class:'overview-map-label-bg'});
     append(g,'text',{x:x+(side<0?labelW-5:5),y:y+4,'text-anchor':side<0?'end':'start',class:'overview-map-label'},county.name);
     const choose=()=>setSharedSection(county.id);g.addEventListener('click',choose);g.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();choose();}});
   }
 }
 // On the county map, spatial dots and an accessible directory lead to the same complete interchange.
 for(const g of gs){const q=p(DATA.groups[g].center);
   const dot=append(roads,'circle',{cx:q[0],cy:q[1],r:c?4.6:2.3,class:'overview-exit-dot'});append(dot,'title',{},`${groupLabel(g)} · ${groupNames[g]}`);
   if(c){const hit=append(svg,'circle',{cx:q[0],cy:q[1],r:14,fill:'transparent','aria-hidden':'true',class:'overview-exit-hit'});hit.addEventListener('click',()=>openOverviewGroup(g));}
 }
 if(c){
  const labels=gs.map((g,i)=>({g,point:p(DATA.groups[g].center),side:i%2?1:-1}));
  for(const side of [-1,1]){const a=labels.filter(x=>x.side===side).sort((a,b)=>a.point[1]-b.point[1]);let last=34;for(const v of a){v.y=Math.max(v.point[1],last);last=v.y+28;}for(let i=a.length-1;i>=0;i--)a[i].y=Math.min(a[i].y,i===a.length-1?height-32:a[i+1].y-28);}
  for(const {g,point:q,side,y} of labels){const x=clamp(q[0]+side*56,34,width-34);append(svg,'path',{d:`M${q[0]} ${q[1]}L${x} ${y}`,class:'overview-leader','aria-hidden':'true'});const t=append(svg,'text',{x:x+side*4,y:y+4,'text-anchor':side<0?'end':'start',class:'overview-exit-label','aria-hidden':'true'},g);t.addEventListener('click',()=>openOverviewGroup(g));}
 }
 append(svg,'text',{x:width-25,y:26,'text-anchor':'end',class:'overview-north','aria-hidden':'true'},'N ↑');
 $('overviewShapes').textContent=c?`Browse ${rs.length} ramp shapes`:`Browse all ${records.length} ramp shapes`;
}
function openOverviewGroup(g){
 if(!DATA.groups[g])return;setGroup(g,{drawAtlas:false});state.selected=null;state.focus=false;switchWorkspace('explore',{scroll:true});
}
function drawLocator(){
 const svg=$('locatorSVG');svg.replaceChildren();const p=fit(DATA.corridor_bounds,83,110,{left:12,right:12,top:10,bottom:10});
 for(const l of DATA.corridor_mainlines)append(svg,'path',{d:xyPath(l.xy,p),fill:'none',stroke:token('--muted'),'stroke-width':.85,'stroke-linejoin':'round'});
 const q=p(DATA.groups[state.group].center);append(svg,'circle',{cx:q[0],cy:q[1],r:5.6,fill:token('--paper'),stroke:token('--green'),'stroke-width':1.3});append(svg,'circle',{cx:q[0],cy:q[1],r:2.6,fill:token('--exit-on-paper')});
 svg.setAttribute('aria-label',`${groupLabel(state.group)} on the full Parkway`);$('locatorNumber').textContent=groupLabel(state.group);$('locatorSection').textContent=groupCounties(state.group).join(' / ')+' County';
}
function drawCollectionLocator(){
 const svg=$('collectionLocator');if(!svg)return;svg.replaceChildren();
 const p=fit(DATA.corridor_bounds,150,360,{left:26,right:28,top:33,bottom:35});
 const seen=new Set(atlasFiltered().map(r=>r.group));
 for(const l of DATA.corridor_mainlines)append(svg,'path',{d:xyPath(l.xy,p),fill:'none',stroke:'#a9b9af','stroke-width':1.3,'stroke-linecap':'round'});
 for(const g of groupOrder){const q=p(DATA.groups[g].center);append(svg,'circle',{cx:q[0],cy:q[1],r:g===state.group?3.8:2,fill:g===state.group?'#ffbd40':seen.has(g)?'#d7e6dc':'#71887e',stroke:'#243331','stroke-width':.8});}
 for(const [g,label] of [[groupOrder[0],groupOrder[0]],[groupOrder.at(-1),groupOrder.at(-1)]]){const q=p(DATA.groups[g].center);append(svg,'rect',{x:q[0]-19,y:g==='172'?q[1]-27:q[1]+7,width:38,height:20,rx:3,fill:'#064d3d',stroke:'#d7e5dc','stroke-width':1});append(svg,'text',{x:q[0],y:g==='172'?q[1]-13:q[1]+21,'text-anchor':'middle',fill:'#fffefa','font-family':'Arial','font-size':12},label);}
 append(svg,'text',{x:12,y:19,fill:'#e6ede5','font-size':11},'N ↑');
 const secs=$('collectionSections');secs.innerHTML=`<button data-section="" aria-pressed="${!state.section}">Full Parkway <span>172–0</span></button>`+countySections.map(c=>`<button data-section="${c.id}" aria-pressed="${state.section===c.id}">${esc(c.name)} <span>${c.groups.length}</span></button>`).join('');
 secs.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>setSharedSection(b.dataset.section)));
}
function switchWorkspace(view,{scroll=false}={}){
 if(!['overview','explore','atlas','compare','design'].includes(view))return;
 state.workspace=view;if(state.tour&&view!=='explore')toggleTour(false);
 for(const [id,workspace] of [['overview','overview'],['explore','explore'],['atlas','atlas'],['compareDialog','compare'],['design','design']])$(id).hidden=view!==workspace;
 document.querySelectorAll('[data-workspace]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.workspace===view)));
 $('openComparison').setAttribute('aria-pressed',String(view==='compare'));
 $('sectionSelect').disabled=['compare','design'].includes(view);refreshSharedControls();
 if(view==='overview')drawOverview();else if(view==='explore'){drawMain();renderRelated();requestAnimationFrame(()=>centerExitNav(false));}else if(view==='atlas')drawAtlas();else if(view==='compare')drawComparison();
 updateComparisonUI();if(scroll)$('workspace').scrollIntoView({behavior:reduced.matches?'auto':'smooth',block:'start'});
}
function comparisonOptionHTML(){
 return '<option value="">Choose a ramp…</option>'+countySections.map(c=>`<optgroup label="${c.label}">${records.filter(r=>COUNTY.by_group[r.group].primary===c.name).map(r=>`<option value="${r.fid}">${esc(r.number+' · '+movement(r)+' · '+r.road)}</option>`).join('')}</optgroup>`).join('');
}
function toggleTour(force){
 state.tour=typeof force==='boolean'?force:!state.tour;state.tourElapsed=0;
 $('tourToggle').innerHTML=state.tour?'<span aria-hidden="true">■</span><span class="sr-only">Stop the tour</span>':'<span aria-hidden="true">▶</span><span class="sr-only">Play a north-to-south tour</span>';
 $('tourToggle').setAttribute('aria-pressed',String(state.tour));$('tourToggle').title=state.tour?'Stop tour':`Tour ${areaLabel()}`;
 if(state.tour){switchWorkspace('explore');setPlaying(true);setGroup(scopedGroups()[0],{fromTour:true,scrollNav:true});}
}
function updateSearch(){
 const q=normalSearch($('exitSearch').value);searchActive=-1;searchItems=[];
 if(!q){closeSearch();return;}
 const cq=q.replace(/\bcounty\b/g,'').trim();
 for(const c of countySections)if(normalSearch(c.name).includes(cq)&&cq.length>1)searchItems.push({county:c.id,title:c.label,sub:`${c.groups.length} access groups · ${c.record_count} selected paths`});
 const tokens=q.split(' '),numeric=/^\d+[a-z]?$/.test(q),matching=records.filter(r=>{if(numeric)return r.number.toLowerCase()===q||r.group.toLowerCase()===q;const text=normalSearch([r.number,r.group,r.road,groupNames[r.group],movement(r),...groupCounties(r.group)].join(' '));return tokens.every(t=>text.includes(t));});
 const groups=groupOrder.filter(g=>matching.some(r=>r.group===g));
 if(numeric&&DATA.groups[q.toUpperCase()]){const g=q.toUpperCase();searchItems.push({group:g,fid:null,title:`${groupLabel(g)} · ${groupNames[g]}`,sub:`Open ${DATA.groups[g].fids.length} selected paths · ${groupCounties(g).join(' / ')}`});}
 else if(!numeric&&!searchItems.length)for(const g of groups.slice(0,3))searchItems.push({group:g,fid:null,title:`${groupLabel(g)} · ${groupNames[g]}`,sub:`Open interchange · ${groupCounties(g).join(' / ')}`});
 matching.slice(0,Math.max(0,10-searchItems.length)).forEach(r=>searchItems.push({group:r.group,fid:r.fid,title:`${r.number} · ${movement(r)}`,sub:r.road}));
 $('searchStatus').textContent=matching.length?`${matching.length} matching paths across the full Parkway${searchItems.length===10?' · first 10 results shown':''}`:searchItems.length?'Choose a county':'No matching exit, road or county in this study.';
 $('searchResults').innerHTML=searchItems.map((r,i)=>`<div id="search-option-${i}" role="option" aria-selected="false" data-result="${i}"><strong>${esc(r.title)}</strong><small>${esc(r.sub)}</small></div>`).join('');
 $('searchPanel').hidden=false;$('exitSearch').setAttribute('aria-expanded','true');$('exitSearch').removeAttribute('aria-activedescendant');
 $('searchResults').querySelectorAll('[data-result]').forEach(b=>{b.addEventListener('mousedown',e=>e.preventDefault());b.addEventListener('click',()=>chooseSearch(Number(b.dataset.result)));});
}
function chooseSearch(i){
 const item=searchItems[i];if(!item)return;
 closeSearch();$('exitSearch').value='';
 if(item.county){setSharedSection(item.county);switchWorkspace('overview',{scroll:true});return;}
 const outside=state.section&&!scopedGroups().includes(item.group);const previous=areaLabel();
 if(outside){state.section='';state.filters.group='';}
 setGroup(item.group,{drawAtlas:false});state.selected=item.fid;state.focus=false;switchWorkspace('explore',{scroll:true});setSelectionDisplay();updateHighlight();
 if(outside)toast(`This result is outside ${previous}. Showing the full Parkway.`);
 const dest=item.fid?$('branchList').querySelector(`[data-fid="${item.fid}"]`):$('groupNumber');dest?.setAttribute('tabindex',dest.tagName==='BUTTON'?'0':'-1');dest?.focus({preventScroll:true});
}
function initCountyUI(){
 $('resetScope').addEventListener('click',()=>resetToFull());$('overviewBack').addEventListener('click',()=>resetToFull());
 $('overviewShapes').addEventListener('click',()=>{state.collection='all';state.filters={group:'',direction:'',kind:''};refreshSharedControls();switchWorkspace('atlas',{scroll:true});});
 $('overviewInterchanges').addEventListener('click',()=>switchWorkspace('explore',{scroll:true}));
 $('exitJump').addEventListener('change',()=>setGroup($('exitJump').value,{scrollNav:true}));
 $('brandHome').addEventListener('click',e=>{e.preventDefault();resetToFull();window.scrollTo({top:0,behavior:reduced.matches?'auto':'smooth'});});
 $('emptyReset').addEventListener('click',()=>{state.collection='all';resetFilters();});
 window.addEventListener('resize',()=>{clearTimeout(overviewTimer);overviewTimer=setTimeout(()=>{if(state.workspace==='overview')drawOverview();},180);});
 $('themeToggle').addEventListener('click',()=>{if(state.workspace==='overview')drawOverview();});
 $('saveCountyData').addEventListener('click',()=>save('GSP_county_navigation.json',JSON.stringify(COUNTY,null,2),'application/json'));
 $('saveOverview').addEventListener('click',()=>{
  const svg=$('overviewSVG'),copy=svg.cloneNode(true),all=[svg,...svg.querySelectorAll('*')],clones=[copy,...copy.querySelectorAll('*')];
  all.forEach((e,i)=>{const css=getComputedStyle(e);for(const key of ['fill','stroke','stroke-width','stroke-dasharray','stroke-linecap','stroke-linejoin','font-family','font-size','font-weight','opacity','text-anchor'])clones[i].style.setProperty(key,css.getPropertyValue(key));clones[i].removeAttribute('tabindex');clones[i].removeAttribute('role');});
  copy.setAttribute('xmlns',NS);copy.setAttribute('width',svg.viewBox.baseVal.width);copy.setAttribute('height',svg.viewBox.baseVal.height);
  copy.insertBefore(node('rect',{width:'100%',height:'100%',fill:token('--paper')}),copy.firstChild);
  copy.insertBefore(node('metadata',{},JSON.stringify({scope:areaLabel(),county_provenance:COUNTY.provenance,road_snapshot:'2025-08-21'})),copy.firstChild);
  save(`GSP_${state.section||'full_parkway'}_overview.svg`,new XMLSerializer().serializeToString(copy),'image/svg+xml');
 });
 refreshSharedControls();switchWorkspace('overview');
}

init();
initParkway();
initCountyUI();

