# The shape of a turn — full scope and county browsing

Navigation/functional revision: October 12, 2026.

## Open

Open `GSP_Parkway_County_Refined.html` in a browser. It contains the HTML, styles,
application and both datasets. No map service, analytics, remote fonts or CDN is
needed. This is a review build, not a live NJ PBS deployment.

For an editable multi-file site, use `index.html` with the `assets` folder beside
it. All data are embedded; a local server is optional. `style-guide.html` is the
standalone design reference. The noindex directive is not access control.

## Default and navigation

The initial screen is **Full Parkway · 172–0**, with no county selected.
The full overview displays all 84 access groups and 359 selected source paths.
Use county map labels, the county directory, or Area to browse a county. Home and
Full Parkway reset to the complete overview. No arbitrary research batches
control the interface.

The 10 navigation counties, north to south, are Bergen, Passaic, Essex, Union,
Middlesex, Monmouth, Ocean, Burlington, Atlantic and Cape May. County numbers in
the directory summarize associated selected interchange groups; they are not
exact county milepost limits. Group 142 appears in Essex and Union. Full totals
and the full grid are deduplicated; county totals must not be summed as if they
were disjoint. The full grid uses a primary-county grouping based on the greatest
total selected-path overlap. County-specific views keep all paths of associated
interchanges, including border-crossing parts.

Search spans the full collection regardless of county and also accepts counties.
Opening a search result outside the active county returns to full scope with a
visible notice. Direction/ramp-type filters and collection mode persist when
switching views. An incompatible interchange filter is cleared on county change.
Comparison selectors include all source records, irrespective of the county.

## Geometry and county-source limits

`data/study-data.json` is byte-for-byte identical to the preceding complete atlas.
All 359 records, 84 group contexts, 359 individual contexts and 12,877 ramp XY
vertices are unchanged. Geometry is the uploaded August 21, 2025 NJDOT snapshot.
This is a selected-path atlas, not an inventory of every ramp or permitted trip.
Width is illustrative; no survey or current sign verification was added.

County navigation is a **separate** derived data layer. It uses NJOGIS county
outlines recovered from the user's NJ Name Atlas, whose source note records
September 11, 2026 retrieval and generalization for display. The prior
simplification tolerance is not recorded. A fresh full-resolution county feature
download was not used. The generalized copy is adequate for regional browsing,
but near-border affiliations are approximate and must not be represented as
legal or survey-grade boundaries. The source URL, precision caveat, thresholds,
overlap lengths and association results are in `data/county-navigation.json`.
Only county geometry and a New Jersey coastal display mask were carried over;
no unrelated name-history profiles, personal information or font files are included.

## Editing and rebuilding

- `assets/tokens.css`: unchanged approved colors and design roles.
- `assets/styles.css`: approved visual foundation plus county/overview layout.
- `assets/app.js`: application, shared county state, interactions and exports.
- `index.html`: page structure and inline datasets.
- `data/county_interchange_crosswalk.csv`: human-readable county audit.

Run `python build_standalone.py` after edits. It refreshes both embedded data blocks
from `data/`, updates the token snapshot, and creates the single-file review HTML.
The builder needs only Python's standard library. Do not edit roadway data as a
side effect of a styling or navigation update.

To reproduce the county association from the shipped display copy, install
`shapely` and `pyproj`, run `python rebuild_counties.py`, then rebuild the HTML.
This does not improve the original boundary precision.

## Checks and dependencies

The shipped audit scripts require Playwright and Chromium. They load the review
HTML through Playwright `set_content`; the modular test serves its own assets
through intercepted requests, without external network access. Install the
Playwright Chromium browser where no system Chromium is available.

```
python tests/qa_core.py
python tests/qa_responsive.py
python tests/qa_exports.py
python tests/qa_motion.py
python verify_source.py --html GSP_Parkway_County_Refined.html --roads-zip /path/to/NJ_Roads_shp.zip
```

The original NJDOT ZIP is not duplicated in this kit. The source verifier requires
that exact archive and checks its checksum before comparing source FIDs, SRIs,
complete vertex arrays and indexed highway excerpts. It does not verify signs.

See `QA.md` and `checks/` for test scope and results. Cross-browser certification,
a formal accessibility audit and live CMS/deployment integration remain outside
this local review build.
