# County-scope refinement

## Fixed
- Removed contradictory southern development defaults. One initial state now opens the full Parkway overview.
- Removed batch-driven navigation. County and full-corridor scopes govern the same data across explorer, collection, locator and overview.
- Corrected stale interchange totals when the scope changes but the selected interchange remains the same.
- Preserved useful collection filters; cleared only incompatible interchange filters.
- Added meaningful empty-state recovery and disabled empty exports.
- Prevented duplicated border-group cards and duplicate options in comparison selectors.
- Preserved source FID, application selection key and source vertex range in comparison exports.
- Scoped tours and previous/next traversal to the chosen county; full scope still traverses all groups.
- Added county/exit search, explicit out-of-county result handling, and keyboard focus recovery.
- Fixed a delayed search-blur timer that could close a newly reopened results list during rapid searches.
- Updated collection counts to the selected area instead of showing an unrelated full-study count.

## Preserved
All original source coordinates, selected records, GIS metadata, contextual road geometry, source warnings, approved color tokens and existing ramp controls. Counties are a separate derived layer, not modifications to roadway data.
