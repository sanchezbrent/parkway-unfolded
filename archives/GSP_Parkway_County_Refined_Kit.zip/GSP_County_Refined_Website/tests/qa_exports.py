import shutil
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,csv,io,re,traceback
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1];DL=ROOT/'checks/export-samples';DL.mkdir(exist_ok=True)
R={'suite':'exports and packaged assets','checks':[],'errors':[]}; original=json.loads((ROOT/'data/study-data.json').read_text())
def ck(name,ok):
 R['checks'].append({'name':name,'passed':bool(ok)});print('PASS' if ok else 'FAIL',name,flush=True)
 if not ok:raise AssertionError(name)
def download(page,id):
 with page.expect_download(timeout=6000) as job:page.locator(id).click()
 d=job.value;path=DL/d.suggested_filename;d.save_as(str(path));return path
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=shutil.which('chromium') or None,headless=True,args=['--no-sandbox'])
  page=b.new_page(viewport={'width':1512,'height':1050},reduced_motion='reduce',accept_downloads=True);page.set_default_timeout(4000);page.on('pageerror',lambda e:R['errors'].append(str(e)))
  page.set_content((ROOT/'GSP_Parkway_County_Refined.html').read_text(),wait_until='load')
  f=download(page,'#saveOverview');root=ET.parse(f).getroot();meta=json.loads(root.find('{http://www.w3.org/2000/svg}metadata').text)
  ck('Full overview downloads as valid SVG with provenance',meta['scope']=='Full Parkway' and meta['county_provenance'])
  page.locator('#sectionSelect').select_option('ocean');f=download(page,'#saveOverview');root=ET.parse(f).getroot();ck('County overview SVG scope label',json.loads(root.find('{http://www.w3.org/2000/svg}metadata').text)['scope']=='Ocean County')
  page.locator('#overviewInterchanges').click();f=download(page,'#saveStage');root=ET.parse(f).getroot();meta=json.loads(root.find('{http://www.w3.org/2000/svg}metadata').text)
  ck('Interchange SVG exports exact source arrays',all(next(r['source_xy'] for r in original['records'] if r['fid']==e['selection_key'])==e['source_xy'] for e in meta['records']))
  page.evaluate("state.section='';setGroup('50');state.selected=-50633;setSelectionDisplay();openDetail(-50633,[-50633]);")
  f=download(page,'#saveBranch');meta=json.loads(ET.parse(f).getroot().find('{http://www.w3.org/2000/svg}metadata').text);r=meta['records'][0]
  ck('Excerpt SVG preserves original FID / synthetic selection key',r['source_fid']==50633 and r['selection_key']==-50633 and r['source_vertex_range'] is not None)
  page.locator('#closeDetail').click();page.locator('#viewShapes').click();page.locator('#sectionSelect').select_option('burlington')
  f=download(page,'#saveAtlas');meta=json.loads(ET.parse(f).getroot().find('{http://www.w3.org/2000/svg}metadata').text)
  ck('County collection SVG contains all six Burlington selections once',len(meta['records'])==6 and len({r['selection_key'] for r in meta['records']})==6)
  page.locator('#unfoldButton').click();f=download(page,'#saveAtlas');ck('Geographic atlas SVG well formed',ET.parse(f).getroot().tag.endswith('svg'))
  page.locator('#openComparison').click();page.locator('#compareA').select_option('-50633');page.locator('#compareB').select_option('5524');page.locator('[data-compare-scale="same"]').click()
  f=download(page,'#saveComparison');meta=json.loads(ET.parse(f).getroot().find('{http://www.w3.org/2000/svg}metadata').text)
  ck('Comparison exports same-scale declaration and correct excerpt identity',meta['comparison_scale']=='same' and meta['records'][0]['fid']==50633 and meta['records'][0]['selection_key']==-50633)
  # Data download controls are deliberately under their source disclosure.
  page.locator('#source-data').evaluate('(el)=>el.open=true')
  f=download(page,'#saveCoordinates');data=json.loads(f.read_text());ck('Coordinate JSON includes unchanged 359 records',data['records']==original['records'])
  f=download(page,'#saveCSV');rows=list(csv.DictReader(io.StringIO(f.read_text())));ck('CSV contains 359 unique selection keys',len(rows)==359 and len({r['selection_key'] for r in rows})==359)
  f=download(page,'#saveGeoJSON');data=json.loads(f.read_text());ck('GeoJSON retains original entire feature collection',data==original['geojson'])
  f=download(page,'#saveCountyData');data=json.loads(f.read_text());ck('County JSON complete independent layer',len(data['counties'])==10 and len(data['by_group'])==84)
  page.locator('[data-open-design]').click();f=download(page,'[data-save-tokens]');ck('Design-token export exact CSS',f.read_text()==(ROOT/'assets/tokens.css').read_text())
  ck('No export JS exceptions',R['errors']==[])
  # A synthetic local origin is served entirely by Playwright; no network / account is used.
  loaded=[]
  def serve(route):
   name=route.request.url.split('/assets/')[-1];path=ROOT/'assets'/name
   if path.exists():
    loaded.append(name);route.fulfill(status=200,content_type='application/javascript' if name.endswith('.js') else 'text/css',body=path.read_text())
   else:route.abort()
  page2=b.new_page(viewport={'width':1512,'height':1050},reduced_motion='reduce');page2.on('pageerror',lambda e:R['errors'].append(str(e)))
  page2.route('https://parkway.local/assets/**',serve)
  modular=(ROOT/'index.html').read_text().replace('<head>','<head><base href="https://parkway.local/">',1)
  page2.set_content(modular,wait_until='load')
  ck('Modular entry loads CSS, tokens and JavaScript',set(loaded)=={'app.js','styles.css','tokens.css'})
  ck('Modular entry opens full scope',page2.evaluate("state.workspace==='overview'&&state.section===''&&records.length===359"))
  ck('No modular entry JS exceptions',R['errors']==[])
  b.close()
except Exception as e:R['failure']=str(e);R['traceback']=traceback.format_exc();print(R['traceback'])
finally:
 (ROOT/'checks/export-audit.json').write_text(json.dumps(R,indent=2))
 if R.get('failure'):raise SystemExit(1)
