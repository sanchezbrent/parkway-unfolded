import shutil
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,traceback
ROOT=Path(__file__).resolve().parents[1];html=(ROOT/'GSP_Parkway_County_Refined.html').read_text()
R={'suite':'responsive and comparison','checks':[],'errors':[]}
def ck(name,result):
 R['checks'].append({'name':name,'passed':bool(result)});print('PASS' if result else 'FAIL',name,flush=True)
 if not result:raise AssertionError(name)
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=shutil.which('chromium') or None,headless=True,args=['--no-sandbox'])
  for w in [320,390,768,1512]:
   page=b.new_page(viewport={'width':w,'height':950 if w<800 else 1050},reduced_motion='reduce');page.set_default_timeout(5000)
   page.on('pageerror',lambda e:R['errors'].append(str(e)));page.set_content(html,wait_until='load')
   ck(f'{w}: starts with full scope',page.evaluate("state.section===''&&state.workspace==='overview'"))
   ck(f'{w}: overview no page overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
   page.screenshot(path=str(ROOT/f'previews/overview-{w}.png'))
   page.locator('#sectionSelect').select_option('ocean');page.screenshot(path=str(ROOT/f'previews/ocean-{w}.png'))
   ck(f'{w}: county overview no overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
   page.locator('#overviewInterchanges').click()
   ck(f'{w}: explorer no page overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
   if w<681:ck(f'{w}: map before branch list',page.evaluate("$('stageMap').getBoundingClientRect().top<$('branchList').getBoundingClientRect().top"))
   page.locator('#viewShapes').click()
   ck(f'{w}: atlas unique records',page.evaluate('atlasNodes.length===70&&new Set(atlasNodes.map(a=>a.r.fid)).size===70'))
   ck(f'{w}: atlas no overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
   page.screenshot(path=str(ROOT/f'previews/shapes-{w}.png'))
   page.locator('#unfoldButton').click();ck(f'{w}: county geographic view',page.evaluate('state.morph===0'))
   page.locator('#openComparison').click()
   ck(f'{w}: comparison chooser unique',page.evaluate("$('compareA').options.length===360&&new Set([...$('compareA').options].map(o=>o.value)).size===360"))
   ck(f'{w}: comparison no overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
   page.locator('[data-compare-scale="same"]').click()
   values=page.evaluate("compareProjects.map((p,i)=>p.s*$('compareSVG'+i).getScreenCTM().a)")
   ck(f'{w}: same pixels per source foot',abs(values[0]-values[1])<1e-9)
   page.screenshot(path=str(ROOT/f'previews/compare-{w}.png'))
   page.locator('[data-compare-scale="fit"]').click()
   values=page.evaluate("compareProjects.map((p,i)=>p.s*$('compareSVG'+i).getScreenCTM().a)")
   ck(f'{w}: fitted scales independent',abs(values[0]-values[1])>1e-6)
   # Sparse source + synthetic excerpt key must both work in comparison.
   page.locator('#compareA').select_option('-50633');page.locator('#compareB').select_option('5529')
   ck(f'{w}: excerpt and sparse source supported',page.evaluate("state.compare[0]===-50633&&compareProjects.every(p=>p&&isFinite(p.s))"))
   page.locator('#compareB').select_option('');ck(f'{w}: partial pair export disabled',page.locator('#saveComparison').is_disabled())
   ck(f'{w}: partial pair remains partial',page.evaluate('state.compare[1]===null'))
   page.locator('#viewOverview').click();ck(f'{w}: county scope retained from comparison',page.locator('#sectionSelect').input_value()=='ocean')
   page.locator('#themeToggle').click();ck(f'{w}: dark theme works',page.evaluate("document.body.classList.contains('night')&&state.section==='ocean'"))
   page.locator('#themeToggle').click();ck(f'{w}: light theme restored',page.evaluate("!document.body.classList.contains('night')"))
   page.locator('[data-open-design]').click();ck(f'{w}: design view',page.evaluate("state.workspace==='design'"))
   ck(f'{w}: design no page overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
   page.locator('#brandHome').click();ck(f'{w}: full overview home',page.evaluate("state.workspace==='overview'&&state.section===''"))
   page.close()
  ck('No JS exceptions',R['errors']==[]);b.close()
except Exception as e:
 R['failure']=str(e);R['traceback']=traceback.format_exc();print(R['traceback'])
finally:
 (ROOT/'checks/responsive-audit.json').write_text(json.dumps(R,indent=2))
 if R.get('failure'):raise SystemExit(1)
