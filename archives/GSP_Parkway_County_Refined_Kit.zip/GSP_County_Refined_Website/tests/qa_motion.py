import shutil
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path(__file__).resolve().parents[1];R={'suite':'motion, keyboard and transitions','checks':[],'errors':[]}
def ck(name,v):
 R['checks'].append({'name':name,'passed':bool(v)});print('PASS' if v else 'FAIL',name,flush=True)
 if not v:raise AssertionError(name)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium') or None,headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':1512,'height':1050},reduced_motion='no-preference');page.set_default_timeout(5000);page.on('pageerror',lambda e:R['errors'].append(str(e)))
 page.set_content((ROOT/'GSP_Parkway_County_Refined.html').read_text(),wait_until='load')
 page.locator('[data-map-county="ocean"]').focus();page.keyboard.press('Enter')
 ck('Keyboard county selection and focus recovery',page.evaluate("state.section==='ocean'&&document.activeElement.id==='overviewTitle'"))
 page.locator('#overviewInterchanges').click();page.locator('[data-group="82"]').focus();page.keyboard.press('Enter')
 ck('Keyboard exit selection retains focus',page.evaluate("state.group==='82'&&document.activeElement.dataset.group==='82'"))
 time0=page.evaluate('state.time');page.wait_for_timeout(250);ck('Normal motion clock advances',page.evaluate('state.time')>time0)
 page.locator('#motionToggle').click();t=page.evaluate('state.time');page.wait_for_timeout(200);ck('Pause stops motion clock',page.evaluate('state.time')==t)
 page.locator('#viewShapes').click();page.locator('#unfoldButton').click();page.wait_for_timeout(2050)
 ck('Animated morph reaches geography',page.evaluate('state.morph===0&&state.morphAnimation===null'))
 page.locator('#unfoldButton').click();page.wait_for_timeout(2050)
 ck('Animated morph reaches shape grid',page.evaluate('state.morph===1&&state.morphAnimation===null'))
 page.locator('#unfoldButton').click();page.wait_for_timeout(140);page.locator('#sectionSelect').select_option('bergen')
 ck('Scope change during morph settles cleanly',page.evaluate("state.section==='bergen'&&state.morphAnimation===null&&[0,1].includes(state.morph)&&atlasNodes.length===34"))
 page.emulate_media(reduced_motion='reduce');ck('Reduced-motion transition pauses automatically',page.evaluate('state.playing===false'))
 page.locator('#viewInterchanges').click();page.locator('#branchList button').first.click();page.locator('#focusBranch').click()
 ck('Focus active before group switch',page.evaluate('state.focus'))
 page.locator('#nextGroup').click();ck('Group switch clears focus and old selection',page.evaluate('!state.focus&&state.selected===null'))
 # Fullscreen is entered by explicit user activation and then exited via the same control.
 page.locator('#fullScreen').click();page.wait_for_timeout(150)
 ck('Expand-map control',page.evaluate("!!document.fullscreenElement||$('stageShell').classList.contains('expanded')"))
 page.locator('#fullScreen').click();page.wait_for_timeout(150)
 ck('Expand-map return',page.evaluate("!document.fullscreenElement&&!$('stageShell').classList.contains('expanded')"))
 ck('No JS exceptions',R['errors']==[]);b.close()
(ROOT/'checks/motion-keyboard-audit.json').write_text(json.dumps(R,indent=2))
