# Release checks — October 12, 2026

149 / 149 recorded assertions passed in the shipped browser audit reports.

- All 84 interchange views: expected source paths and navigation.
- All 359 inspectors: correct identity, original source points and end trace.
- All 10 county scopes: counts, associated groups and deduplicated collections.
- Full-scope startup, overview map/directory, county switching and clean Home reset.
- Interchange 142 under Essex and Union; full selection remains 359 distinct keys.
- Search by county, exit/suffix, Access 12, out-of-county result, no-results and Escape.
- Collection filter persistence, no-source-results recovery, geographic/grid transition.
- Source-point display, selected-ramp focus, whole-interchange return and modal close.
- County tour beginning, next group, ending and pause behavior.
- Widths 320, 390, 768 and 1512 pixels: no page-level horizontal overflow in overview,
  explorer, collection, comparison or design guide; map precedes branch choices on phones.
- Real screen pixels per source foot in same-scale comparison at all four widths;
  independent fitted scales, partial pairs, duplicate prevention and source excerpts.
- Dark/light theme, normal/reduced motion, keyboard map/exit activation and focus recovery.
- Explicit map expand/return controls.
- Actual downloads: full/county overview SVG, interchange SVG, individual excerpt SVG,
  grid/geographic collection SVG, comparison SVG, coordinate JSON, CSV, GeoJSON,
  county provenance JSON and design tokens. XML/JSON parsed and identities checked.
- Modular entry loads its own CSS/JavaScript and starts at full scope.
- Independent standard-library SHP/SHX/DBF reader: all 359 selections and 12,877 XY
  vertices exactly match the uploaded NJDOT ZIP; all previous records and contexts preserved.

Browser coverage: Chromium only. These checks are not a full accessibility audit,
a Safari/Firefox certification, a live-server deployment test or road-condition verification.

County precision is limited to the recovered, previously generalized NJOGIS display copy.
The county overlay is for navigation, not a legal boundary survey. The original boundary
simplification tolerance was not recorded. Close-border cases remain approximate.

Machine-readable reports are in `checks/`; screenshots are actual browser renders.
