#!/usr/bin/env python3
"""Recompute navigation counties from the shipped generalized county copy.
Requires shapely and pyproj. Run build_standalone.py afterward to update the HTML.
Not a legal boundary assessment; the source precision warning is retained.
"""
from pathlib import Path
import json,hashlib
from shapely.geometry import shape,LineString,Point,mapping
from shapely.ops import transform,unary_union
from pyproj import Transformer
P=Path(__file__).resolve().parent/'data';D=json.loads((P/'study-data.json').read_text())
raw=json.loads((P/'njogis_county_display_copy.geojson').read_text());context=json.loads((P/'nj_coast_display.geojson').read_text())
trans=Transformer.from_crs(4326,3424,always_xy=True).transform
polys={f['properties']['name']:transform(trans,shape(f['geometry'])).buffer(0) for f in raw['features']}
byid={r['fid']:r for r in D['records']};lines={fid:LineString(r['source_xy']) for fid,r in byid.items()}
ms=[(l,LineString(l['xy'])) for l in D['corridor_mainlines']]
cs={name:sum(l.intersection(p).length for _,l in ms) for name,p in polys.items()}
# Carriageways can overlap in plan; these totals are not Parkway travel mileage.
byrecord={}
for fid,line in lines.items():
 cov={n:line.intersection(poly).length for n,poly in polys.items() if line.intersects(poly)}
 cov={n:v for n,v in cov.items() if v>0.01}
 primary=max(cov,key=cov.get) if cov else min(polys,key=lambda n:line.distance(polys[n]))
 byrecord[str(fid)]={'primary':primary,'overlap_ft':{n:round(v,3) for n,v in cov.items()},'counties':[n for n,v in cov.items() if v>=max(15,line.length*.005)] or [primary]}
bygroup={}
for g,group in D['groups'].items():
 cov={n:sum(lines[fid].intersection(p).length for fid in group['fids']) for n,p in polys.items()};cov={n:v for n,v in cov.items() if v>0.01}
 primary=max(cov,key=cov.get)
 counties=sorted({n for fid in group['fids'] for n in byrecord[str(fid)]['counties']},key=lambda n:cov.get(n,0),reverse=True)
 # Keep every adjoining county; minor slivers are recorded but not used for navigation.
 bygroup[g]={'primary':primary,'counties':counties,'overlap_ft':{n:round(v,3) for n,v in cov.items()}}
 print(g,primary,' / '.join(counties),[(n,round(v)) for n,v in cov.items()])
order=['Bergen','Passaic','Essex','Union','Middlesex','Monmouth','Ocean','Burlington','Atlantic','Cape May']
assert set(n for n,v in cs.items() if v>50)==set(order)
def fragments(geom):
 if geom.is_empty:return []
 if geom.geom_type=='LineString':return [geom]
 return [x for a in geom.geoms for x in fragments(a)]
counties=[]
for name in order:
 poly=polys[name];gids=[g for g in D['group_order'] if name in bygroup[g]['counties']]
 clips=[]
 for l,line in ms:
  for frag in fragments(line.intersection(poly)):
   if frag.length>1:clips.append({'sri':l['sri'],'xy':list(frag.coords),'role':'mainline'})
 coords=[p for l in clips for p in l['xy']]
 for g in gids:
  for fid in D['groups'][g]['fids']:coords.extend(byid[fid]['source_xy'])
 bounds=[min(p[0] for p in coords),min(p[1] for p in coords),max(p[0] for p in coords),max(p[1] for p in coords)]
 counties.append({'id':name.lower().replace(' ','-'),'name':name,'label':name+' County','groups':gids,'primary_groups':[g for g in gids if bygroup[g]['primary']==name],'record_count':sum(len(D['groups'][g]['fids']) for g in gids),'bounds':bounds,'mainlines':clips,'geometry':mapping(poly)})
 print('county',name,len(gids),'groups',sum(len(D['groups'][g]['fids']) for g in gids),'paths')
# Context coast is a cartographic display mask, never used for county association.
nj=next(f for f in context['features'] if f['properties']['name']=='New Jersey')
land=transform(trans,shape(nj['geometry'])).buffer(0)
R={'schema_version':1,'provenance':{'boundary_source':'NJOGIS NJ Counties 3857 hosted feature layer','boundary_url':'https://services2.arcgis.com/XVOqAjTOJ5P6ngMu/ArcGIS/rest/services/NJ_Counties_3857/FeatureServer/0','boundary_copy':'County-only geometry extracted from the user’s NJ_Name_Atlas.html Library artifact. No name-history research data is reused.','source_retrieved_as_stated':'2026-09-11','processed_on':'2026-10-12','boundary_precision':'Previously generalized for display; original simplification tolerance not recorded in that artifact. Not a boundary survey.','join_method':'Line/polygon intersections after transforming the stored longitude/latitude polygons into EPSG:3424. Keep whole interchanges. Additional county membership requires at least max(15 feet, 0.5% of a selected branch length) of overlap. Minor overlaps remain in audit. Primary county has the most total selected-path length.','border_note':'Generalized county boundaries are suitable for browsing. Near-boundary affiliations are approximate; groups associated with more than one county are available in both and deduplicated in the full collection.','road_data_unchanged_sha256':hashlib.sha256((P/'study-data.json').read_bytes()).hexdigest(),'land_context':'NJ-only coastline from the prior atlas’s Census 2017 / us-atlas 3.0.1 display mask; not used in county association.'},'counties':counties,'by_group':bygroup,'by_record':byrecord,'land':mapping(land)}

for county in counties:
 line=max((LineString(l['xy']) for l in county['mainlines']),key=lambda l:l.length)
 county['label_point']=list(line.interpolate(.5,normalized=True).coords[0])
R['full_bounds']=list(land.bounds)
(P/'county-navigation.json').write_text(json.dumps(R,separators=(',',':')))
print('saved', (P/'county-navigation.json').stat().st_size)
